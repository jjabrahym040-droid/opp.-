import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect } from "react";
import {
  LayoutDashboard, Package, ShoppingBag, Users, CreditCard, Tags, LogOut, Store
} from "lucide-react";

const navItems = [
  { to: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
  { to: "/admin/products", icon: Package, label: "المنتجات" },
  { to: "/admin/categories", icon: Tags, label: "التصنيفات" },
  { to: "/admin/orders", icon: ShoppingBag, label: "الطلبات" },
  { to: "/admin/customers", icon: Users, label: "العملاء" },
  { to: "/admin/payments", icon: CreditCard, label: "المدفوعات" },
];

const AdminLayout = ({ children }: { children: React.ReactNode }) => {
  const { user, isAdmin, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || !isAdmin) navigate("/auth");
  }, [user, isAdmin, navigate]);

  if (!user || !isAdmin) return null;

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="w-60 bg-card border-r border-border flex flex-col flex-shrink-0 hidden md:flex">
        <div className="p-4 border-b border-border">
          <Link to="/admin" className="text-lg font-bold text-primary">متجري</Link>
          <div className="text-xs text-muted-foreground mt-0.5">لوحة التحكم</div>
        </div>
        <nav className="flex-1 p-2 space-y-0.5">
          {navItems.map(item => (
            <Link
              key={item.to}
              to={item.to}
              className={`flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors ${
                location.pathname === item.to
                  ? "bg-primary/10 text-primary font-semibold"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-border space-y-1">
          <Link to="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary px-3 py-2">
            <Store className="w-4 h-4" /> زيارة المتجر
          </Link>
          <button onClick={async () => { await logout(); navigate("/"); }} className="flex items-center gap-2 text-sm text-destructive px-3 py-2 w-full">
            <LogOut className="w-4 h-4" /> تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-card border-b border-border p-3 flex items-center justify-between z-50">
        <Link to="/admin" className="text-base font-bold text-primary">متجري - لوحة التحكم</Link>
        <Link to="/" className="text-muted-foreground"><Store className="w-5 h-5" /></Link>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <header className="bg-card border-b border-border p-4 hidden md:flex items-center justify-between">
          <h2 className="font-semibold text-sm">مرحباً، {user.name}</h2>
          <div className="text-xs text-muted-foreground">{new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-auto mt-12 md:mt-0">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-2 z-50">
        {navItems.slice(0, 5).map(item => (
          <Link
            key={item.to}
            to={item.to}
            className={`flex flex-col items-center gap-0.5 text-[10px] ${
              location.pathname === item.to ? "text-primary" : "text-muted-foreground"
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default AdminLayout;
