import StoreHeader from "./StoreHeader";
import StoreFooter from "./StoreFooter";
import BottomNav from "./BottomNav";

const StoreLayout = ({ children, hideHeader, hideFooter, hideBottomNav }: { children: React.ReactNode; hideHeader?: boolean; hideFooter?: boolean; hideBottomNav?: boolean }) => (
  <div className="min-h-screen flex flex-col bg-background">
    {!hideHeader && <StoreHeader />}
    <main className="flex-1 md:pb-0" style={{ paddingBottom: hideBottomNav ? 0 : 150 }}>{children}</main>
    {!hideFooter && <StoreFooter />}
    {!hideBottomNav && <BottomNav />}
  </div>
);

export default StoreLayout;
