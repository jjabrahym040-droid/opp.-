import { Link, useLocation } from "react-router-dom";
import { Home, Search, ShoppingCart, User, Check, Truck } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

const ROYAL_BLUE = "#0A1F44";
const BLACK = "#0B0B0B";

const BottomNav = () => {
  const location = useLocation();
  const { totalItems } = useCart();
  const path = location.pathname;

  const items = [
    { to: "/", icon: Home, label: "Home", match: "/" },
    { to: "/products", icon: Search, label: "Shop", match: "/products" },
    { to: "/cart", icon: ShoppingCart, label: "Cart", match: "/cart", badge: totalItems },
    { to: "/track", icon: Truck, label: "Track", match: "/track" },
    { to: "/account", icon: User, label: "Account", match: "/account" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t-2 safe-area-bottom" style={{ borderColor: ROYAL_BLUE }}>
      <div className="flex items-center justify-around py-1.5">
        {items.map(item => {
          const active = item.match === "/" ? path === "/" : path.startsWith(item.match);
          const activeColor = ROYAL_BLUE;
          return (
            <Link key={item.to} to={item.to} className="flex flex-col items-center gap-0.5 relative min-w-[56px]">
              <div className="relative">
                {active && item.match === "/" ? (
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: activeColor }}>
                    <Check className="w-4 h-4 text-white" strokeWidth={2.5} />
                  </div>
                ) : active ? (
                  <div className="relative">
                    <item.icon className="w-6 h-6" strokeWidth={2} style={{ color: activeColor }} />
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full flex items-center justify-center" style={{ backgroundColor: activeColor }}>
                      <Check className="w-2 h-2 text-white" strokeWidth={3} />
                    </div>
                  </div>
                ) : (
                  <item.icon className="w-6 h-6" strokeWidth={1.75} style={{ color: BLACK }} />
                )}
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 text-[9px] font-black rounded-full w-4 h-4 flex items-center justify-center text-white" style={{ backgroundColor: activeColor }}>
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-medium" style={{ color: active ? activeColor : BLACK }}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
