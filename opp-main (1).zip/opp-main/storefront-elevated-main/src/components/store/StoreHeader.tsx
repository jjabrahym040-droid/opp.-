import { useNavigate } from "react-router-dom";
import { Search, MapPin, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useCurrency } from "@/contexts/CurrencyContext";
import CountrySelector from "./CountrySelector";

const StoreHeader = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const { country } = useCurrency();
  const [openCountry, setOpenCountry] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#eee]">
      {/* Top: Deliver to + brand */}
      <div className="px-4 pt-2 pb-1 flex items-center justify-between">
        <button
          onClick={() => setOpenCountry(true)}
          className="flex items-center gap-1 text-[13px] font-semibold text-[#0B0B0B]"
        >
          <MapPin className="w-3.5 h-3.5" strokeWidth={2} />
          <span>Deliver to {country.name}</span>
          <ChevronDown className="w-3 h-3" strokeWidth={2.5} />
        </button>
        <span className="text-[13px] font-bold tracking-tight text-[#0A1F44]">
          ULTRA-X <span className="text-[#E53935]">STORE</span>
        </span>
      </div>

      {/* Black capsule search */}
      <div className="px-3 pb-2 pt-1">
        <form onSubmit={handleSearch} className="flex items-center bg-black rounded-full overflow-hidden h-10 pl-4 pr-1">
          <Search className="w-4 h-4 text-white flex-shrink-0" strokeWidth={2.2} />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search anything..."
            className="flex-1 px-3 py-2 bg-transparent text-[13px] text-white placeholder:text-[#bbb] outline-none"
          />
          <button type="submit" className="bg-white rounded-full text-black text-[12px] font-semibold px-4 py-1.5 mr-1">
            Go
          </button>
        </form>
      </div>

      {openCountry && <CountrySelectorModal onClose={() => setOpenCountry(false)} />}
    </header>
  );
};

// Inline standalone modal trigger that reuses CountrySelector by mounting it open
const CountrySelectorModal = ({ onClose }: { onClose: () => void }) => {
  // Simple wrapper that auto-opens CountrySelector — we hide its trigger
  return (
    <div onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="hidden">
        {/* mounting point */}
      </div>
      <ForceOpenCountrySelector onClose={onClose} />
    </div>
  );
};

const ForceOpenCountrySelector = ({ onClose }: { onClose: () => void }) => {
  const { country, setCountry, countries } = useCurrency();
  const [query, setQuery] = useState("");
  const filtered = countries.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) || c.currency.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[100] bg-black/40 flex items-end sm:items-center justify-center">
      <div className="bg-white w-full sm:max-w-md sm:rounded-lg rounded-t-2xl max-h-[85vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-[#eee]">
          <h2 className="text-base font-semibold text-[#0A1F44]">Deliver to</h2>
          <button onClick={onClose}>
            <span className="text-2xl leading-none">×</span>
          </button>
        </div>
        <div className="p-3 border-b border-[#eee]">
          <div className="flex items-center gap-2 bg-[#f5f5f7] rounded-md px-3 py-2">
            <Search className="w-4 h-4 text-[#999]" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search country..." className="flex-1 bg-transparent text-sm outline-none" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.map(c => (
            <button
              key={c.code}
              onClick={() => { setCountry(c); onClose(); }}
              className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#fafafa] border-b border-[#f5f5f5]"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{c.flag}</span>
                <div className="text-left">
                  <div className="text-sm font-medium text-[#191919]">{c.name}</div>
                  <div className="text-[11px] text-[#666]">{c.currency} · {c.symbol}</div>
                </div>
              </div>
              {country.code === c.code && <span className="text-[#0A1F44] font-bold">✓</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StoreHeader;
