import { useState } from "react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { ChevronDown, X, Check, Search } from "lucide-react";

const CountrySelector = () => {
  const { country, setCountry, countries } = useCurrency();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = countries.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) || c.currency.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-1 text-[12px] font-medium text-[#0A1F44] hover:text-[#1565C0]"
      >
        <span className="text-base leading-none">{country.flag}</span>
        <span>{country.currency}</span>
        <ChevronDown className="w-3 h-3" strokeWidth={2} />
      </button>

      {open && (
        <div className="fixed inset-0 z-[100] bg-black/40 flex items-end sm:items-center justify-center">
          <div className="bg-white w-full sm:max-w-md sm:rounded-lg rounded-t-2xl max-h-[85vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-[#eee]">
              <h2 className="text-base font-semibold text-[#0A1F44]">Choose country & currency</h2>
              <button onClick={() => setOpen(false)}>
                <X className="w-5 h-5 text-[#191919]" />
              </button>
            </div>
            <div className="p-3 border-b border-[#eee]">
              <div className="flex items-center gap-2 bg-[#f5f5f7] rounded-md px-3 py-2">
                <Search className="w-4 h-4 text-[#999]" />
                <input
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Search..."
                  className="flex-1 bg-transparent text-sm outline-none"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filtered.map(c => (
                <button
                  key={c.code}
                  onClick={() => { setCountry(c); setOpen(false); }}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#fafafa] border-b border-[#f5f5f5]"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{c.flag}</span>
                    <div className="text-left">
                      <div className="text-sm font-medium text-[#191919]">{c.name}</div>
                      <div className="text-[11px] text-[#666]">{c.currency} · {c.symbol} · Tax {c.taxRate}%</div>
                    </div>
                  </div>
                  {country.code === c.code && (
                    <Check className="w-5 h-5 text-[#0A1F44]" strokeWidth={2.5} />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CountrySelector;
