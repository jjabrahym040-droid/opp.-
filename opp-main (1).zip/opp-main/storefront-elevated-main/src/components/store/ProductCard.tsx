import { Link } from "react-router-dom";
import { Star, Flame } from "lucide-react";
import type { Product } from "@/data/products";
import { useCurrency } from "@/contexts/CurrencyContext";

interface ProductCardProps {
  product: Product;
}

const formatSold = (n: number) => {
  if (n >= 10000) return `${Math.floor(n / 1000)}K+`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K+`;
  return `${n}+`;
};

const ProductCard = ({ product }: ProductCardProps) => {
  const { format } = useCurrency();

  return (
    <Link
      to={`/product/${product.id}`}
      className="block bg-white overflow-hidden"
      style={{ borderRadius: 0, border: "none" }}
    >
      {/* 1:1 square image — product is the hero, no padding */}
      <div className="relative overflow-hidden bg-[#f5f5f5]" style={{ aspectRatio: "1/1" }}>
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        {/* AliExpress "توفير" badge — matte orange, top-left */}
        <div
          className="absolute top-1.5 left-1.5 text-white leading-none"
          style={{
            background: "linear-gradient(135deg,#FF6200 0%,#e85500 100%)",
            fontSize: 9,
            fontWeight: 700,
            padding: "3px 7px",
            borderRadius: 3,
            letterSpacing: "0.02em",
          }}
        >
          توفير
        </div>
      </div>

      {/* ── Institutional split price tag ── */}
      <div
        className="relative flex overflow-hidden"
        style={{ height: 40, borderTop: "1px solid #ede6ff" }}
      >
        {/* Left dark wedge — discount badge */}
        <div
          className="relative flex items-center justify-center flex-shrink-0"
          style={{
            background: "linear-gradient(170deg,#2a2a2a 0%,#1e1e1e 100%)",
            clipPath: "polygon(0 0,100% 0,80% 100%,0 100%)",
            minWidth: 48,
            paddingLeft: 8,
            paddingRight: 16,
          }}
        >
          {/* Gloss sheen */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              clipPath: "polygon(0 0,100% 0,80% 100%,0 100%)",
              background: "linear-gradient(180deg,rgba(255,255,255,0.12) 0%,transparent 55%)",
            }}
          />
          <span className="relative z-10 text-white font-bold leading-none" style={{ fontSize: 9, letterSpacing: "0.02em" }}>
            −50%
          </span>
        </div>

        {/* Right lavender panel — matte soft gradient */}
        <div
          className="flex-1 relative flex flex-col justify-center overflow-hidden"
          style={{
            marginLeft: -2,
            background: "linear-gradient(160deg,#EDE6FF 0%,#E8DFFF 50%,#DFD5FF 100%)",
            paddingLeft: 10,
            paddingRight: 8,
          }}
        >
          {/* Top gloss layer */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: "linear-gradient(180deg,rgba(255,255,255,0.38) 0%,transparent 55%)" }}
          />
          <span
            className="relative z-10 font-bold leading-none"
            style={{ fontSize: 13, letterSpacing: "-0.01em", color: "#262626" }}
            dir="ltr"
          >
            {format(product.price)}
          </span>
          <span
            className="relative z-10 leading-none mt-0.5"
            style={{ fontSize: 8, color: "#7a68b0", fontWeight: 400 }}
          >
            New user price
          </span>
        </div>
      </div>

      {/* Product info — tight, thin typography */}
      <div style={{ padding: "7px 9px 10px", background: "#fff" }}>
        <h3
          className="line-clamp-2 leading-snug"
          style={{ fontSize: 11.5, fontWeight: 400, color: "#2d2d2d", marginBottom: 4, letterSpacing: "-0.01em" }}
        >
          {product.name}
        </h3>

        {product.soldCount > 0 && (
          <div className="flex items-center gap-1" style={{ fontSize: 10 }}>
            <Star className="flex-shrink-0" style={{ width: 9, height: 9 }} fill="#f5a623" strokeWidth={0} />
            <span style={{ fontWeight: 500, color: "#555" }}>{product.rating}</span>
            <span style={{ color: "#e0e0e0" }}>·</span>
            <Flame className="flex-shrink-0" style={{ width: 9, height: 9, color: "#ff6200" }} strokeWidth={1.5} />
            <span style={{ color: "#aaa" }}>{formatSold(product.soldCount)} sold</span>
          </div>
        )}
      </div>
    </Link>
  );
};

export default ProductCard;
