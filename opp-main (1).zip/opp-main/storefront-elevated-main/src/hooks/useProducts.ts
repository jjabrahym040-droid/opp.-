import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Product, Category } from "@/data/products";

interface ProductRow {
  id: string;
  name: string;
  description: string;
  price: number;
  original_price: number | null;
  category: string | null;
  image: string;
  images: string[];
  brand: string;
  store: string;
  features: string[];
  stock_count: number;
  in_stock: boolean;
  is_super_deal: boolean;
  sold_count: number;
  rating: number;
  review_count: number;
}

const rowToProduct = (r: ProductRow): Product => ({
  id: r.id,
  name: r.name,
  description: r.description,
  price: Number(r.price),
  originalPrice: r.original_price != null ? Number(r.original_price) : undefined,
  category: r.category || "",
  image: r.image,
  images: r.images?.length ? r.images : [r.image],
  brand: r.brand || "",
  store: r.store || "ULTRA-X Store",
  features: r.features || [],
  stockCount: r.stock_count,
  inStock: r.in_stock,
  isSuperDeal: r.is_super_deal,
  soldCount: r.sold_count,
  rating: Number(r.rating),
  reviewCount: r.review_count,
});

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      const { data } = await supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false });
      if (!cancelled && data) setProducts((data as ProductRow[]).map(rowToProduct));
      setLoading(false);
    };
    load();

    const channel = supabase
      .channel("products-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, () => {
        load();
      })
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, []);

  return { products, loading };
};

export const useProduct = (id: string | undefined) => {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!id) { setLoading(false); return; }
    let cancelled = false;
    supabase.from("products").select("*").eq("id", id).maybeSingle().then(({ data }) => {
      if (!cancelled) {
        setProduct(data ? rowToProduct(data as ProductRow) : null);
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
  }, [id]);
  return { product, loading };
};

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      const { data } = await supabase.from("categories").select("*").order("sort_order");
      if (!cancelled && data) {
        setCategories(data.map((c: any) => ({ id: c.id, name: c.name, icon: c.icon || "📦", image: c.image })));
      }
    };
    load();
    const channel = supabase
      .channel("categories-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "categories" }, load)
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(channel); };
  }, []);
  return categories;
};
