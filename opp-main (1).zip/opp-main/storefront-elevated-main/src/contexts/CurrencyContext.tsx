import React, { createContext, useContext, useEffect, useState } from "react";

export interface Country {
  code: string;
  name: string;
  flag: string;
  currency: string;
  symbol: string;
  rate: number; // multiplier from base USD
  taxRate: number; // VAT/sales tax %
  locale: string;
  dialCode: string;
}

export const DIAL_CODES: Record<string, string> = {
  US: "+1", GB: "+44", EU: "+33", CA: "+1", AU: "+61", EG: "+20", SA: "+966",
  AE: "+971", KW: "+965", QA: "+974", BH: "+973", OM: "+968", JO: "+962",
  MA: "+212", DZ: "+213", TN: "+216", TR: "+90", CN: "+86", JP: "+81",
  IN: "+91", BR: "+55", RU: "+7", ZA: "+27", MX: "+52",
};

// Rates relative to USD base (1 USD = X currency)
const RAW: Omit<Country, "dialCode">[] = [
  { code: "US", name: "United States", flag: "🇺🇸", currency: "USD", symbol: "$",   rate: 1,      taxRate: 0,    locale: "en-US" },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧", currency: "GBP", symbol: "£", rate: 0.79,   taxRate: 20,   locale: "en-GB" },
  { code: "EU", name: "Europe",         flag: "🇪🇺", currency: "EUR", symbol: "€", rate: 0.92,   taxRate: 20,   locale: "en-IE" },
  { code: "CA", name: "Canada",         flag: "🇨🇦", currency: "CAD", symbol: "C$",rate: 1.36,   taxRate: 5,    locale: "en-CA" },
  { code: "AU", name: "Australia",      flag: "🇦🇺", currency: "AUD", symbol: "A$",rate: 1.52,   taxRate: 10,   locale: "en-AU" },
  { code: "EG", name: "Egypt",          flag: "🇪🇬", currency: "EGP", symbol: "EGP",rate: 48.7,  taxRate: 14,   locale: "en-EG" },
  { code: "SA", name: "Saudi Arabia",   flag: "🇸🇦", currency: "SAR", symbol: "SAR",rate: 3.75,  taxRate: 15,   locale: "en-SA" },
  { code: "AE", name: "UAE",            flag: "🇦🇪", currency: "AED", symbol: "AED",rate: 3.67,  taxRate: 5,    locale: "en-AE" },
  { code: "KW", name: "Kuwait",         flag: "🇰🇼", currency: "KWD", symbol: "KWD",rate: 0.31,  taxRate: 0,    locale: "en-KW" },
  { code: "QA", name: "Qatar",          flag: "🇶🇦", currency: "QAR", symbol: "QAR",rate: 3.64,  taxRate: 0,    locale: "en-QA" },
  { code: "BH", name: "Bahrain",        flag: "🇧🇭", currency: "BHD", symbol: "BHD",rate: 0.38,  taxRate: 10,   locale: "en-BH" },
  { code: "OM", name: "Oman",           flag: "🇴🇲", currency: "OMR", symbol: "OMR",rate: 0.39,  taxRate: 5,    locale: "en-OM" },
  { code: "JO", name: "Jordan",         flag: "🇯🇴", currency: "JOD", symbol: "JOD",rate: 0.71,  taxRate: 16,   locale: "en-JO" },
  { code: "MA", name: "Morocco",        flag: "🇲🇦", currency: "MAD", symbol: "MAD",rate: 9.95,  taxRate: 20,   locale: "en-MA" },
  { code: "DZ", name: "Algeria",        flag: "🇩🇿", currency: "DZD", symbol: "DZD",rate: 134,   taxRate: 19,   locale: "en-DZ" },
  { code: "TN", name: "Tunisia",        flag: "🇹🇳", currency: "TND", symbol: "TND",rate: 3.13,  taxRate: 19,   locale: "en-TN" },
  { code: "TR", name: "Turkey",         flag: "🇹🇷", currency: "TRY", symbol: "₺",  rate: 34.2,  taxRate: 18,   locale: "en-TR" },
  { code: "CN", name: "China",          flag: "🇨🇳", currency: "CNY", symbol: "¥",  rate: 7.27,  taxRate: 13,   locale: "en-CN" },
  { code: "JP", name: "Japan",          flag: "🇯🇵", currency: "JPY", symbol: "¥",  rate: 151,   taxRate: 10,   locale: "en-JP" },
  { code: "IN", name: "India",          flag: "🇮🇳", currency: "INR", symbol: "₹",  rate: 84,    taxRate: 18,   locale: "en-IN" },
  { code: "BR", name: "Brazil",         flag: "🇧🇷", currency: "BRL", symbol: "R$", rate: 5.6,   taxRate: 17,   locale: "en-BR" },
  { code: "RU", name: "Russia",         flag: "🇷🇺", currency: "RUB", symbol: "₽",  rate: 90,    taxRate: 20,   locale: "en-RU" },
  { code: "ZA", name: "South Africa",   flag: "🇿🇦", currency: "ZAR", symbol: "R",  rate: 18.1,  taxRate: 15,   locale: "en-ZA" },
  { code: "MX", name: "Mexico",         flag: "🇲🇽", currency: "MXN", symbol: "$",  rate: 20.4,  taxRate: 16,   locale: "en-MX" },
];

export const COUNTRIES: Country[] = RAW.map(c => ({ ...c, dialCode: DIAL_CODES[c.code] || "+1" }));

interface CurrencyContextType {
  country: Country;
  setCountry: (c: Country) => void;
  format: (usdAmount: number) => string;
  convert: (usdAmount: number) => number;
  countries: Country[];
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [country, setCountryState] = useState<Country>(COUNTRIES[0]);

  useEffect(() => {
    const saved = localStorage.getItem("country");
    if (saved) {
      const c = COUNTRIES.find(x => x.code === saved);
      if (c) setCountryState(c);
    }
  }, []);

  const setCountry = (c: Country) => {
    setCountryState(c);
    localStorage.setItem("country", c.code);
    document.documentElement.lang = "en";
    document.documentElement.dir = "ltr";
  };

  const convert = (usdAmount: number) => usdAmount * country.rate;

  const format = (usdAmount: number) => {
    const v = convert(usdAmount);
    const isLargeUnit = country.rate >= 50;
    const formatted = isLargeUnit
      ? Math.round(v).toLocaleString("en-US")
      : v.toLocaleString("en-US", { maximumFractionDigits: 2, minimumFractionDigits: 2 });
    return `${country.symbol}${formatted}`;
  };

  return (
    <CurrencyContext.Provider value={{ country, setCountry, format, convert, countries: COUNTRIES }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error("useCurrency must be used within CurrencyProvider");
  return ctx;
};
