import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User as SupabaseUser, Session } from "@supabase/supabase-js";

export interface User {
  id: string;
  name: string;
  email: string;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  sendOtp: (email: string) => Promise<{ ok: boolean; error?: string }>;
  verifyOtp: (email: string, token: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_EMAIL = "abrahymjrhy391@gmail.com";

function baseUser(su: SupabaseUser): User {
  const meta = su.user_metadata || {};
  return {
    id: su.id,
    name: meta.full_name || meta.name || su.email?.split("@")[0] || "مستخدم",
    email: su.email || "",
    isAdmin: su.email === ADMIN_EMAIL, // optimistic; refined by DB role check
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const refineRole = useCallback(async (u: User) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", u.id)
      .eq("role", "admin")
      .maybeSingle();
    setUser({ ...u, isAdmin: !!data || u.email === ADMIN_EMAIL });
  }, []);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      const u = sess?.user ? baseUser(sess.user) : null;
      setUser(u);
      setLoading(false);
      if (u) setTimeout(() => refineRole(u), 0);
    });

    supabase.auth.getSession().then(({ data: { session: sess } }) => {
      setSession(sess);
      const u = sess?.user ? baseUser(sess.user) : null;
      setUser(u);
      setLoading(false);
      if (u) refineRole(u);
    });

    return () => subscription.unsubscribe();
  }, [refineRole]);

  const sendOtp = useCallback(async (email: string): Promise<{ ok: boolean; error?: string }> => {
    // Do NOT pass emailRedirectTo — that turns the email into a magic link instead of a 6-digit code
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { shouldCreateUser: true },
    });
    if (error) {
      console.error("[sendOtp]", error);
      return { ok: false, error: error.message };
    }
    return { ok: true };
  }, []);

  const verifyOtp = useCallback(async (email: string, token: string): Promise<{ ok: boolean; error?: string }> => {
    const { error } = await supabase.auth.verifyOtp({ email, token, type: "email" });
    if (error) {
      console.error("[verifyOtp]", error);
      return { ok: false, error: error.message };
    }
    return { ok: true };
  }, []);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, session, loading, sendOtp, verifyOtp, logout, isAdmin: user?.isAdmin ?? false }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
