import StoreLayout from "@/components/store/StoreLayout";
import ProductCard from "@/components/store/ProductCard";
import ProductCardSkeleton from "@/components/store/ProductCardSkeleton";
import { useProducts } from "@/hooks/useProducts";

/* Clean promo banner — no cartoons, professional gradient */
const PromoBanner = () => (
  <section
    className="mx-3 mt-3 mb-2 rounded-xl overflow-hidden relative"
    style={{
      background: "linear-gradient(110deg, #0a2d6e 0%, #1053c7 55%, #1a7fff 100%)",
      minHeight: 96,
      boxShadow: "0 2px 12px rgba(16,83,199,0.25)",
    }}
  >
    {/* Subtle light ray */}
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        background: "radial-gradient(ellipse 60% 80% at 75% 30%, rgba(255,255,255,0.10) 0%, transparent 70%)",
      }}
    />
    <div className="relative z-10 px-4 py-3.5">
      <div className="flex items-center gap-1.5 mb-1.5">
        <span
          className="text-[9px] font-semibold px-2 py-0.5 rounded-full tracking-wide"
          style={{ background: "rgba(255,255,255,0.18)", color: "rgba(255,255,255,0.95)", letterSpacing: "0.05em" }}
        >
          LIMITED OFFER
        </span>
        <span className="text-[10px]" style={{ color: "rgba(255,255,255,0.6)" }}>Ends soon</span>
      </div>
      <div className="text-white font-semibold text-[17px] leading-tight tracking-tight">
        Shop Trending Products
      </div>
      <div className="mt-1" style={{ color: "rgba(255,255,255,0.65)", fontSize: 11 }}>
        Worldwide shipping · Buyer protection · Best price
      </div>
    </div>
    {/* Decorative ring */}
    <div
      className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full border border-white/10"
      style={{ width: 80, height: 80 }}
    />
    <div
      className="absolute right-8 top-1/2 -translate-y-1/2 rounded-full border border-white/8"
      style={{ width: 50, height: 50 }}
    />
  </section>
);

/* Section header */
const SectionLabel = ({ label }: { label: string }) => (
  <div className="flex items-center gap-2 px-3 pt-2 pb-1.5">
    <span className="text-[12px] font-semibold text-[#111] tracking-tight">{label}</span>
    <div className="flex-1 h-px bg-[#eee]" />
  </div>
);

const Index = () => {
  const { products, loading } = useProducts();

  return (
    <StoreLayout>
      <PromoBanner />
      <SectionLabel label="Recommended for You" />

      {loading ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2, paddingBottom: 150 }}>
          {Array.from({ length: 8 }).map((_, i) => <ProductCardSkeleton key={i} />)}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-20 px-4">
          <p className="text-[13px] font-medium text-[#191919] mb-1">No products yet</p>
          <p className="text-[12px] text-[#999]">Add products from the admin panel</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2, paddingBottom: 150 }}>
          {products.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </StoreLayout>
  );
};

export default Index;
