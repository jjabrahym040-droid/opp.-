import { useState } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { ChevronLeft, Package, Truck, MapPin, CheckCircle2, Mail, Shield, FileText, Lock, RefreshCw, X } from "lucide-react";
import { toast } from "sonner";

const ROYAL_BLUE = "#0A1F44";
const ROYAL_BLUE_LIGHT = "#1B3A7A";
const BLACK = "#0B0B0B";

const TrackOrder = () => {
  const navigate = useNavigate();
  const [showSupport, setShowSupport] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);
  const [supportMsg, setSupportMsg] = useState("");
  const [supportEmail, setSupportEmail] = useState("");

  // Mock current order with progress
  const order = {
    id: "ORD-2026-001",
    name: "ميكروفون ديناميكي FIFINE USB/XLR مع تحكم RGB",
    image: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=400&h=400&fit=crop",
    price: 2822.55,
    currentStep: 2, // 0..3
    eta: "أبريل 12, 2026",
    tracking: "EG2026040112345",
  };

  const steps = [
    { icon: Package, label: "قيد التجهيز", sub: "تم استلام الطلب" },
    { icon: Truck, label: "تم الشحن", sub: "غادر المستودع" },
    { icon: MapPin, label: "اقتربت من الوصول", sub: "في طريقها إليك" },
    { icon: CheckCircle2, label: "تم التسليم", sub: "وصل الطلب" },
  ];

  const handleSendSupport = () => {
    if (!supportEmail || !supportMsg) {
      toast.error("الرجاء إدخال البريد والرسالة");
      return;
    }
    // Open mail client as fallback
    window.location.href = `mailto:support@shopzone.com?subject=طلب دعم - ${order.id}&body=${encodeURIComponent(supportMsg)}%0A%0A--%0A${supportEmail}`;
    toast.success("تم فتح بريد المساعدة");
    setShowSupport(false);
    setSupportMsg("");
    setSupportEmail("");
  };

  return (
    <StoreLayout hideHeader hideFooter>
      {/* Header */}
      <div className="sticky top-0 z-40 px-4 py-3.5 flex items-center justify-between border-b" style={{ backgroundColor: BLACK, borderColor: ROYAL_BLUE_LIGHT }}>
        <button onClick={() => navigate(-1)}>
          <ChevronLeft className="w-6 h-6 text-white rotate-180" strokeWidth={2} />
        </button>
        <h1 className="text-base font-black text-white">تابع طلبك</h1>
        <div className="w-6" />
      </div>

      <div className="bg-white min-h-screen">
        {/* Tracking number bar */}
        <div className="px-4 py-3 flex items-center justify-between" style={{ backgroundColor: ROYAL_BLUE }}>
          <span className="text-xs text-white/70 font-medium" dir="ltr">{order.tracking}</span>
          <span className="text-xs text-white font-bold">رقم التتبع</span>
        </div>

        {/* Order card */}
        <div className="p-4 border-b border-[#eee] flex gap-3 items-center">
          <img src={order.image} alt={order.name} className="w-20 h-20 rounded-xl object-cover flex-shrink-0" />
          <div className="flex-1 text-right">
            <h2 className="text-sm font-bold text-[#0B0B0B] line-clamp-2 leading-relaxed">{order.name}</h2>
            <div className="mt-1.5 flex items-center justify-end gap-2">
              <span className="text-base font-black" style={{ color: ROYAL_BLUE }}>EGP {order.price.toLocaleString()}</span>
            </div>
            <div className="text-[11px] text-[#666] mt-1">التوصيل المتوقع: {order.eta}</div>
          </div>
        </div>

        {/* Progress section */}
        <div className="px-4 py-6">
          <h3 className="text-sm font-black text-right mb-5" style={{ color: BLACK }}>حالة الطلب</h3>

          {/* Horizontal progress bar */}
          <div className="relative mb-6">
            <div className="absolute top-5 right-5 left-5 h-1 rounded-full bg-[#e5e5e5]" />
            <div
              className="absolute top-5 right-5 h-1 rounded-full transition-all duration-500"
              style={{
                width: `calc(${(order.currentStep / (steps.length - 1)) * 100}% - 20px)`,
                background: `linear-gradient(90deg, ${ROYAL_BLUE}, ${ROYAL_BLUE_LIGHT})`,
              }}
            />
            <div className="relative flex justify-between" dir="rtl">
              {steps.map((step, i) => {
                const Icon = step.icon;
                const done = i <= order.currentStep;
                const active = i === order.currentStep;
                return (
                  <div key={i} className="flex flex-col items-center w-1/4">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${active ? "ring-4 ring-blue-100" : ""}`}
                      style={{
                        backgroundColor: done ? ROYAL_BLUE : "#fff",
                        borderColor: done ? ROYAL_BLUE : "#ccc",
                      }}
                    >
                      <Icon className="w-5 h-5" style={{ color: done ? "#fff" : "#999" }} strokeWidth={2} />
                    </div>
                    <span className="text-[10px] font-bold mt-2 text-center leading-tight" style={{ color: done ? BLACK : "#999" }}>
                      {step.label}
                    </span>
                    <span className="text-[9px] text-[#999] mt-0.5 text-center leading-tight">{step.sub}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Timeline events */}
          <div className="border-t border-[#eee] pt-4 space-y-3">
            {steps.slice(0, order.currentStep + 1).reverse().map((s, i) => (
              <div key={i} className="flex items-start gap-3 justify-end">
                <div className="text-right flex-1">
                  <div className="text-xs font-bold" style={{ color: BLACK }}>{s.label}</div>
                  <div className="text-[11px] text-[#666] mt-0.5">{s.sub}</div>
                  <div className="text-[10px] text-[#999] mt-0.5">منذ {(i + 1) * 6} ساعات</div>
                </div>
                <div className="w-2.5 h-2.5 rounded-full mt-1.5" style={{ backgroundColor: ROYAL_BLUE }} />
              </div>
            ))}
          </div>
        </div>

        {/* Support button */}
        <div className="px-4 pb-4">
          <button
            onClick={() => setShowSupport(true)}
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2.5 text-white font-black text-sm shadow-lg active:scale-[0.99] transition-transform"
            style={{ background: `linear-gradient(135deg, ${BLACK}, ${ROYAL_BLUE})` }}
          >
            <Mail className="w-5 h-5" strokeWidth={2} />
            بريد المساعدة
          </button>
        </div>

        {/* Policies & Security section */}
        <div className="mt-2 bg-white border-t border-[#eee]">
          <button
            onClick={() => setShowPolicies(!showPolicies)}
            className="w-full px-4 py-4 flex items-center justify-between"
          >
            <ChevronLeft className={`w-5 h-5 text-[#999] transition-transform ${showPolicies ? "rotate-90" : ""}`} strokeWidth={2} />
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-black" style={{ color: BLACK }}>السياسات والأمان</span>
              <Shield className="w-5 h-5" style={{ color: ROYAL_BLUE }} strokeWidth={2} />
            </div>
          </button>

          {showPolicies && (
            <div className="px-4 pb-6 space-y-4 text-right">
              {/* Return policy */}
              <div className="rounded-2xl p-4 border" style={{ borderColor: ROYAL_BLUE, backgroundColor: "#F8FAFF" }}>
                <div className="flex items-center gap-2 justify-end mb-2">
                  <h4 className="text-sm font-black" style={{ color: BLACK }}>سياسة الاسترجاع</h4>
                  <RefreshCw className="w-5 h-5" style={{ color: ROYAL_BLUE }} strokeWidth={2} />
                </div>
                <p className="text-xs text-[#444] leading-relaxed">
                  يحق لك إرجاع المنتج خلال <span className="font-black">15 يوماً</span> من تاريخ الاستلام بشرط أن يكون بحالته الأصلية ومع التغليف الكامل.
                  يتم استرداد المبلغ كاملاً خلال 5–7 أيام عمل بعد فحص المنتج. لا تشمل سياسة الاسترجاع المنتجات المخصصة أو الملابس الداخلية.
                </p>
              </div>

              {/* Privacy */}
              <div className="rounded-2xl p-4 border" style={{ borderColor: ROYAL_BLUE, backgroundColor: "#F8FAFF" }}>
                <div className="flex items-center gap-2 justify-end mb-2">
                  <h4 className="text-sm font-black" style={{ color: BLACK }}>حماية بيانات المستخدم</h4>
                  <Lock className="w-5 h-5" style={{ color: ROYAL_BLUE }} strokeWidth={2} />
                </div>
                <p className="text-xs text-[#444] leading-relaxed">
                  نلتزم بحماية بياناتك الشخصية وفقاً لأعلى المعايير الدولية (GDPR). يتم تشفير جميع المعلومات باستخدام
                  <span className="font-black"> SSL 256-bit</span>، ولا يتم مشاركة بياناتك مع أي طرف ثالث دون إذنك الصريح.
                  جميع المدفوعات تتم عبر بوابات دفع آمنة ومعتمدة عالمياً.
                </p>
              </div>

              {/* Terms */}
              <div className="rounded-2xl p-4 border" style={{ borderColor: ROYAL_BLUE, backgroundColor: "#F8FAFF" }}>
                <div className="flex items-center gap-2 justify-end mb-2">
                  <h4 className="text-sm font-black" style={{ color: BLACK }}>شروط الاستخدام</h4>
                  <FileText className="w-5 h-5" style={{ color: ROYAL_BLUE }} strokeWidth={2} />
                </div>
                <p className="text-xs text-[#444] leading-relaxed">
                  باستخدامك لمنصة ShopZone، فأنت توافق على شروط الاستخدام والامتثال للقوانين المحلية والدولية.
                  نحتفظ بحق تعديل هذه الشروط في أي وقت مع إخطار المستخدمين بأي تغييرات جوهرية.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="h-20" />
      </div>

      {/* Support modal */}
      {showSupport && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60" onClick={() => setShowSupport(false)}>
          <div
            className="w-full max-w-md bg-white rounded-t-3xl p-5 animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setShowSupport(false)}>
                <X className="w-5 h-5 text-[#666]" strokeWidth={2} />
              </button>
              <h3 className="text-base font-black" style={{ color: BLACK }}>بريد المساعدة</h3>
            </div>
            <p className="text-xs text-[#666] text-right mb-4">سنرد على رسالتك خلال 24 ساعة</p>

            <input
              type="email"
              placeholder="بريدك الإلكتروني"
              value={supportEmail}
              onChange={(e) => setSupportEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-[#ddd] text-sm text-right mb-3 focus:outline-none focus:border-[color:var(--rb)]"
              style={{ ["--rb" as never]: ROYAL_BLUE }}
              dir="ltr"
            />
            <textarea
              placeholder="اكتب رسالتك..."
              value={supportMsg}
              onChange={(e) => setSupportMsg(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 rounded-xl border border-[#ddd] text-sm text-right mb-4 focus:outline-none resize-none"
            />
            <button
              onClick={handleSendSupport}
              className="w-full py-3.5 rounded-2xl text-white font-black text-sm"
              style={{ background: `linear-gradient(135deg, ${BLACK}, ${ROYAL_BLUE})` }}
            >
              إرسال الرسالة
            </button>
          </div>
        </div>
      )}
    </StoreLayout>
  );
};

export default TrackOrder;
