import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useCart } from "@/contexts/CartContext";
import { useCurrency, COUNTRIES, type Country } from "@/contexts/CurrencyContext";
import { ChevronLeft, ChevronRight, ShieldCheck, Lock, X, Search, Check } from "lucide-react";
import { toast } from "sonner";

type Step = "address" | "gateway" | "payment-stripe" | "payment-paymob";

/* ─── Engraved Trust Badge ────────────────────────────────────────────────── */
const EngraveBadge = ({
  children,
  bg = "#f4f4f6",
  borderColor = "#d4d4dc",
}: {
  children: React.ReactNode;
  bg?: string;
  borderColor?: string;
}) => (
  <div
    style={{
      background: bg,
      border: `1px solid ${borderColor}`,
      borderRadius: 6,
      padding: "4px 7px",
      boxShadow:
        "inset 0 1px 3px rgba(0,0,0,0.14), inset 0 -1px 1px rgba(255,255,255,0.7), 0 1px 0 rgba(255,255,255,0.9)",
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
    }}
  >
    {children}
  </div>
);

/* ─── Trust badge row — uses official image asset ─────────────────────────── */
const TrustBadges = () => (
  <div className="mt-3.5">
    <img
      src="/trust-badges.png"
      alt="Accepted payment networks"
      className="w-full"
      style={{ borderRadius: 6, maxHeight: 44, objectFit: "contain" }}
    />
  </div>
);

/* ─── Paymob card visual ──────────────────────────────────────────────────── */
const PaymobCard = ({
  number,
  holder,
  expiry,
}: {
  number: string;
  holder: string;
  expiry: string;
}) => (
  <div
    className="mx-3 mb-4 relative overflow-hidden"
    style={{
      borderRadius: 18,
      background: "linear-gradient(135deg, #2196f3 0%, #1565c0 55%, #0d47a1 100%)",
      minHeight: 172,
      boxShadow: "0 8px 32px rgba(21,101,192,0.35), 0 2px 8px rgba(0,0,0,0.18)",
    }}
  >
    {/* Gloss shimmer */}
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        background:
          "radial-gradient(ellipse 80% 40% at 50% 0%, rgba(255,255,255,0.22) 0%, transparent 70%)",
      }}
    />
    {/* Large circle accents */}
    <div
      className="absolute rounded-full"
      style={{ width: 140, height: 140, top: -40, right: -40, background: "rgba(255,255,255,0.07)" }}
    />
    <div
      className="absolute rounded-full"
      style={{ width: 90, height: 90, top: 20, right: 20, background: "rgba(255,255,255,0.05)" }}
    />

    <div className="relative z-10 p-5">
      <div className="flex justify-between items-start mb-4">
        {/* EMV chip */}
        <div
          style={{
            width: 36, height: 28, borderRadius: 5,
            background: "linear-gradient(135deg, #e6c96a 0%, #c9a227 100%)",
            border: "1px solid #b8902a",
            boxShadow: "inset 0 1px 2px rgba(255,255,255,0.4), 0 1px 2px rgba(0,0,0,0.25)",
            display: "grid", gridTemplateColumns: "1fr 1fr", gridTemplateRows: "1fr 1fr 1fr",
            gap: 2, padding: 4,
          }}
        >
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={{ background: "rgba(150,100,10,0.4)", borderRadius: 2 }} />
          ))}
        </div>
        <span style={{ color: "rgba(255,255,255,0.95)", fontWeight: 700, fontSize: 16, letterSpacing: "0.02em" }}>
          paymob<span style={{ color: "rgba(255,255,255,0.6)" }}>.</span>
        </span>
      </div>

      <div className="mb-3">
        <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 8, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 3 }}>
          Card Number
        </div>
        <div style={{ color: "white", fontFamily: "monospace", fontSize: 15, letterSpacing: "3px", fontWeight: 500 }}>
          {number
            ? number.replace(/\D/g, "").padEnd(16, "•").replace(/(.{4})/g, "$1 ").trim()
            : "•••• •••• •••• ••••"}
        </div>
      </div>

      <div className="flex gap-10">
        <div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 8, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 2 }}>
            Card Name
          </div>
          <div style={{ color: "white", fontSize: 13, fontWeight: 600 }}>{holder || "Enter Name"}</div>
        </div>
        <div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 8, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 2 }}>
            Valid Thru
          </div>
          <div style={{ color: "white", fontSize: 13, fontWeight: 600 }}>{expiry || "MM/YY"}</div>
        </div>
      </div>
    </div>
  </div>
);

/* ─── Shared input style ──────────────────────────────────────────────────── */
const inputCls =
  "w-full px-4 py-3.5 bg-white rounded-xl text-[13px] text-[#1a1a1a] placeholder:text-[#bbb] focus:outline-none transition-colors";
const inputStyle = {
  border: "1px solid #e5e5e5",
  boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
};
const inputFocusStyle = { border: "1px solid #0A1F44" };

/* ─── Section card wrapper ────────────────────────────────────────────────── */
const SectionCard = ({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div
    className={`bg-white mx-3 rounded-xl p-4 ${className}`}
    style={{ boxShadow: "0 1px 4px rgba(0,0,0,0.06)", border: "1px solid #f0f0f0" }}
  >
    {children}
  </div>
);

/* ═══════════════════════════════════════════════════════════════════════════ */
const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const { format, country: globalCountry, setCountry: setGlobalCountry } = useCurrency();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("address");

  const [country, setCountry] = useState<Country>(globalCountry);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerQ, setPickerQ] = useState("");

  const [shipping, setShipping] = useState({
    name: "", phone: "", street: "", apartment: "", province: "", city: "", postalCode: "",
  });
  const [card, setCard] = useState({ number: "", holder: "", expiry: "", cvv: "", save: true });

  /* Dial code auto-updates when country changes */
  useEffect(() => {
    setShipping(s => ({ ...s, phone: "" }));
  }, [country.code]);

  useEffect(() => {
    if (items.length === 0) navigate("/cart");
  }, [items.length, navigate]);

  if (items.length === 0) return null;

  const shippingCost = totalPrice >= 50 ? 0 : 4.99;
  const grandTotal = totalPrice + shippingCost;

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shipping.name || !shipping.street || !shipping.city || !shipping.phone) {
      toast.error("Please fill in all required fields");
      return;
    }
    setGlobalCountry(country);
    setStep("gateway");
  };

  const formatCardNumber = (v: string) =>
    v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

  const formatExpiry = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    return d.length >= 3 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
  };

  const handlePay = () => {
    const digits = card.number.replace(/\s/g, "");
    if (digits.length < 13 || !card.holder.trim() || card.expiry.length < 5 || card.cvv.length < 3) {
      toast.error("Please complete all card details");
      return;
    }
    toast.success("Processing payment securely…");
    setTimeout(() => {
      clearCart();
      toast.success("Order placed successfully!");
      navigate("/account");
    }, 1500);
  };

  const goBack = () => {
    if (step === "payment-stripe" || step === "payment-paymob") setStep("gateway");
    else if (step === "gateway") setStep("address");
    else navigate(-1);
  };

  const filteredCountries = COUNTRIES.filter(
    c =>
      c.name.toLowerCase().includes(pickerQ.toLowerCase()) ||
      c.dialCode.includes(pickerQ)
  );

  const headerTitle =
    step === "address" ? "Shipping Address"
    : step === "gateway" ? "Payment Method"
    : step === "payment-stripe" ? "Card Payment"
    : "Paymob Payment";

  return (
    <StoreLayout hideHeader hideBottomNav>

      {/* ── Sticky header ── */}
      <div
        className="sticky top-0 z-40 bg-white px-4 py-3 flex items-center"
        style={{ borderBottom: "1px solid #eee", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}
      >
        <button onClick={goBack} className="p-0.5">
          <ChevronLeft className="w-5 h-5 text-[#111]" strokeWidth={2} />
        </button>
        <h1 className="text-[14px] font-semibold flex-1 text-center text-[#111] tracking-tight">
          {headerTitle}
        </h1>
        <div className="w-5" />
      </div>

      {/* ── Step progress bar ── */}
      {(step === "address" || step === "gateway") && (
        <div className="flex items-center gap-0 px-5 py-2 bg-white border-b border-[#f0f0f0]">
          {/* Step 1 */}
          <div className="flex items-center gap-1.5">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
              style={{
                background: step === "address" ? "#0A1F44" : "#22c55e",
                color: "white",
              }}
            >
              {step === "address" ? "1" : <Check className="w-3 h-3" strokeWidth={3} />}
            </div>
            <span
              className="text-[11px] font-medium"
              style={{ color: step === "address" ? "#0A1F44" : "#22c55e" }}
            >
              Shipping
            </span>
          </div>
          {/* Connector */}
          <div
            className="flex-1 mx-2 h-px"
            style={{ background: step === "gateway" ? "#0A1F44" : "#ddd" }}
          />
          {/* Step 2 */}
          <div className="flex items-center gap-1.5">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
              style={{
                background: step === "gateway" ? "#0A1F44" : "#ddd",
                color: step === "gateway" ? "white" : "#999",
              }}
            >
              2
            </div>
            <span
              className="text-[11px] font-medium"
              style={{ color: step === "gateway" ? "#0A1F44" : "#aaa" }}
            >
              Payment
            </span>
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════
          STEP 1 — SHIPPING ADDRESS
      ════════════════════════════════════════════════════════ */}
      {step === "address" && (
        <form onSubmit={handleAddressSubmit} className="bg-[#f6f6f8] min-h-screen pb-10">

          {/* Country selector */}
          <SectionCard className="mt-4">
            <p className="text-[11px] font-semibold text-[#888] uppercase tracking-wide mb-2.5">
              Country / Region
            </p>
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="w-full flex items-center justify-between rounded-xl px-3.5 py-3"
              style={{ border: "1px solid #e0e0e0", background: "#fafafa", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xl">{country.flag}</span>
                <div className="text-left">
                  <div className="text-[13px] font-medium text-[#111]">{country.name}</div>
                  <div className="text-[10px] text-[#888]" dir="ltr">{country.dialCode} · {country.currency}</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-[#ccc]" />
            </button>
          </SectionCard>

          {/* Personal info */}
          <SectionCard className="mt-3">
            <p className="text-[11px] font-semibold text-[#888] uppercase tracking-wide mb-2.5">
              Personal Information
            </p>
            <div className="space-y-2.5">
              <input
                type="text"
                value={shipping.name}
                onChange={e => setShipping(s => ({ ...s, name: e.target.value }))}
                className={inputCls}
                style={inputStyle}
                onFocus={e => Object.assign(e.target.style, inputFocusStyle)}
                onBlur={e => Object.assign(e.target.style, inputStyle)}
                placeholder="Full name *"
              />
              {/* Phone + auto dial code */}
              <div className="flex gap-2">
                <div
                  className="flex items-center gap-1.5 px-3 rounded-xl flex-shrink-0"
                  style={{ border: "1px solid #e0e0e0", background: "#f5f5f8", minWidth: 90, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}
                >
                  <span className="text-base">{country.flag}</span>
                  <span className="text-[12px] font-semibold text-[#222]" dir="ltr">{country.dialCode}</span>
                </div>
                <input
                  type="tel"
                  value={shipping.phone}
                  onChange={e => setShipping(s => ({ ...s, phone: e.target.value.replace(/\D/g, "") }))}
                  className={`${inputCls} flex-1`}
                  style={inputStyle}
                  placeholder="Phone number *"
                />
              </div>
            </div>
          </SectionCard>

          {/* Address */}
          <SectionCard className="mt-3">
            <p className="text-[11px] font-semibold text-[#888] uppercase tracking-wide mb-2.5">
              Delivery Address
            </p>
            <div className="space-y-2.5">
              <input type="text" value={shipping.street}
                onChange={e => setShipping(s => ({ ...s, street: e.target.value }))}
                className={inputCls} style={inputStyle} placeholder="Street, building, apartment *" />
              <input type="text" value={shipping.apartment}
                onChange={e => setShipping(s => ({ ...s, apartment: e.target.value }))}
                className={inputCls} style={inputStyle} placeholder="Suite / unit (optional)" />
              <div className="grid grid-cols-2 gap-2.5">
                <input type="text" value={shipping.city}
                  onChange={e => setShipping(s => ({ ...s, city: e.target.value }))}
                  className={inputCls} style={inputStyle} placeholder="City *" />
                <input type="text" value={shipping.province}
                  onChange={e => setShipping(s => ({ ...s, province: e.target.value }))}
                  className={inputCls} style={inputStyle} placeholder="Province" />
              </div>
              <input type="text" value={shipping.postalCode}
                onChange={e => setShipping(s => ({ ...s, postalCode: e.target.value }))}
                className={inputCls} style={inputStyle} placeholder="Postal code" />
            </div>
          </SectionCard>

          <div className="px-3 pt-5 pb-8">
            <button
              type="submit"
              className="w-full py-3.5 rounded-xl text-[14px] font-semibold text-white flex items-center justify-center gap-2"
              style={{
                background: "linear-gradient(90deg, #0a2560 0%, #1a5ccc 100%)",
                boxShadow: "0 4px 16px rgba(10,37,96,0.3)",
              }}
            >
              Continue to Payment
              <ChevronRight className="w-4 h-4" strokeWidth={2.5} />
            </button>
          </div>

          {/* Country picker drawer */}
          {pickerOpen && (
            <div
              className="fixed inset-0 z-50 flex items-end"
              style={{ background: "rgba(0,0,0,0.45)" }}
              onClick={() => setPickerOpen(false)}
            >
              <div
                onClick={e => e.stopPropagation()}
                className="bg-white w-full max-h-[85vh] flex flex-col overflow-hidden"
                style={{ borderTopLeftRadius: 20, borderTopRightRadius: 20 }}
              >
                <div className="flex items-center justify-between px-5 py-4 border-b border-[#eee]">
                  <h2 className="text-[14px] font-semibold text-[#111]">Select Country</h2>
                  <button type="button" onClick={() => setPickerOpen(false)}>
                    <X className="w-5 h-5 text-[#666]" />
                  </button>
                </div>
                <div className="px-4 py-2.5 border-b border-[#eee]">
                  <div
                    className="flex items-center gap-2 rounded-lg px-3 py-2"
                    style={{ background: "#f5f5f8" }}
                  >
                    <Search className="w-4 h-4 text-[#aaa]" />
                    <input
                      value={pickerQ}
                      onChange={e => setPickerQ(e.target.value)}
                      placeholder="Search country or dial code…"
                      className="flex-1 bg-transparent text-[13px] outline-none text-[#111] placeholder:text-[#bbb]"
                    />
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {filteredCountries.map(c => (
                    <button
                      type="button"
                      key={c.code}
                      onClick={() => { setCountry(c); setPickerOpen(false); setPickerQ(""); }}
                      className="w-full flex items-center justify-between px-5 py-3 border-b border-[#f5f5f5]"
                      style={{ background: country.code === c.code ? "#f5f8ff" : "white" }}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{c.flag}</span>
                        <div className="text-left">
                          <div className="text-[13px] font-medium text-[#111]">{c.name}</div>
                          <div className="text-[10px] text-[#888]" dir="ltr">
                            {c.dialCode} · {c.currency}
                          </div>
                        </div>
                      </div>
                      {country.code === c.code && (
                        <Check className="w-4 h-4 text-[#0A1F44]" strokeWidth={2.5} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </form>
      )}

      {/* ════════════════════════════════════════════════════════
          STEP 2 — GATEWAY SELECTION
      ════════════════════════════════════════════════════════ */}
      {step === "gateway" && (
        <div className="bg-[#f6f6f8] min-h-screen pb-10">
          <div className="px-4 pt-4 pb-1 text-center">
            <p className="text-[12px] text-[#888]">Choose your preferred payment gateway</p>
          </div>

          {/* Order summary */}
          <SectionCard className="mt-3">
            <p className="text-[11px] font-semibold text-[#888] uppercase tracking-wide mb-2.5">
              Order Summary
            </p>
            <div className="space-y-1.5">
              <div className="flex justify-between text-[12px] text-[#555]">
                <span>Subtotal</span>
                <span dir="ltr">{format(totalPrice)}</span>
              </div>
              <div className="flex justify-between text-[12px] text-[#555]">
                <span>Shipping</span>
                <span dir="ltr">{shippingCost === 0 ? "Free" : format(shippingCost)}</span>
              </div>
              <div
                className="flex justify-between text-[14px] font-semibold text-[#111] pt-2 mt-1"
                style={{ borderTop: "1px solid #eee" }}
              >
                <span>Total</span>
                <span dir="ltr">{format(grandTotal)}</span>
              </div>
            </div>
          </SectionCard>

          {/* Stripe — official logo */}
          <button
            onClick={() => setStep("payment-stripe")}
            className="mx-3 mt-3 w-[calc(100%-24px)] text-left flex items-center justify-between bg-white"
            style={{ border: "1px solid #e8e8e8", borderRadius: 14, boxShadow: "0 2px 15px rgba(0,0,0,0.05)", padding: "14px 16px" }}
          >
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 overflow-hidden" style={{ width: 48, height: 48, borderRadius: 12, boxShadow: "0 2px 8px rgba(99,91,255,0.25)" }}>
                <img src="/stripe-logo.png" alt="Stripe" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#262626" }}>Stripe</div>
                <div style={{ fontSize: 11, color: "#999", marginTop: 2 }}>Visa · Mastercard · Amex · JCB</div>
                <div className="mt-1.5">
                  <img src="/trust-badges.png" alt="card networks" style={{ height: 16, objectFit: "contain", opacity: 0.85 }} />
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: "#ccc" }} />
          </button>

          {/* Paymob — official logo */}
          <button
            onClick={() => setStep("payment-paymob")}
            className="mx-3 mt-2.5 w-[calc(100%-24px)] text-left flex items-center justify-between bg-white"
            style={{ border: "1px solid #e8e8e8", borderRadius: 14, boxShadow: "0 2px 15px rgba(0,0,0,0.05)", padding: "14px 16px" }}
          >
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 overflow-hidden" style={{ width: 48, height: 48, borderRadius: 12, boxShadow: "0 2px 8px rgba(21,101,192,0.2)" }}>
                <img src="/paymob-logo.jpg" alt="Paymob" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#262626" }}>Paymob</div>
                <div style={{ fontSize: 11, color: "#999", marginTop: 2 }}>Egyptian cards &amp; bank wallets</div>
                <div className="flex items-center gap-1 mt-1.5">
                  {["NBE","Meeza","CIB","Banque Misr"].map(b => (
                    <span key={b} style={{ border: "1px solid #e5e5e5", borderRadius: 4, padding: "1px 5px", fontSize: 8, fontWeight: 600, color: "#555", background: "#fafafa" }}>{b}</span>
                  ))}
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: "#ccc" }} />
          </button>

          <div className="flex items-center justify-center gap-1.5 mt-5">
            <ShieldCheck className="w-3.5 h-3.5" style={{ color: "#3EAB61" }} strokeWidth={2} />
            <span style={{ fontSize: 11, color: "#3EAB61" }}>256-bit SSL encrypted · PCI DSS compliant</span>
          </div>
        </div>
      )}

      {step === "payment-stripe" && (
        <div className="min-h-screen pb-36" style={{ background: "#f5f5f5" }}>

          {/* Safety line — matches AliExpress reference */}
          <div className="flex items-center gap-1.5 px-4 pt-3 pb-1">
            <ShieldCheck className="flex-shrink-0" style={{ width: 14, height: 14, color: "#3EAB61" }} strokeWidth={2} />
            <span style={{ fontSize: 12, color: "#3EAB61", fontWeight: 500 }}>Your payment information is safe with us</span>
          </div>

          {/* ── Card information block — 100% Stripe Elements fidelity ── */}
          <div className="mx-3 mt-2.5 bg-white rounded-xl overflow-hidden"
            style={{ border: "1px solid #e8e8e8", boxShadow: "0 2px 15px rgba(0,0,0,0.05)" }}>

            {/* Header row: label + official card brand asset */}
            <div className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: "1px solid #f0f0f0" }}>
              <span style={{ fontSize: 14, fontWeight: 600, color: "#262626" }}>Card information</span>
              <img
                src="/trust-badges.png"
                alt="Visa Mastercard Amex and more"
                style={{ height: 20, objectFit: "contain", maxWidth: 140 }}
              />
            </div>

            {/* Card number row — mirrors Stripe Elements: number input + card icons on right */}
            <div className="flex items-center" style={{ borderBottom: "1px solid #f0f0f0" }}>
              <input
                type="text" inputMode="numeric"
                value={card.number}
                onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))}
                style={{ flex: 1, fontSize: 15, padding: "15px 12px 15px 16px", background: "transparent", outline: "none", color: "#262626", letterSpacing: "0.07em" }}
                placeholder="1234 1234 1234 1234"
              />
              {/* Official card-brand icons — embedded asset */}
              <div className="flex items-center gap-1 pr-3 flex-shrink-0">
                <span style={{ border: "1px solid #d0d5e0", borderRadius: 3, padding: "1px 4px", fontSize: 8.5, fontWeight: 900, color: "#1A1F71", background: "#fff" }}>VISA</span>
                <span style={{ display: "inline-flex", alignItems: "center" }}>
                  <span style={{ width: 13, height: 13, borderRadius: "50%", background: "#EB001B", display: "inline-block", marginRight: -5 }} />
                  <span style={{ width: 13, height: 13, borderRadius: "50%", background: "#F79E1B", display: "inline-block" }} />
                </span>
                <span style={{ border: "1px solid #016FD0", borderRadius: 3, padding: "1px 3px", fontSize: 7.5, fontWeight: 800, background: "#016FD0", color: "white" }}>AM<br/>EX</span>
                <span style={{ border: "1px solid #e0e0e0", borderRadius: 3, padding: "1px 3px", fontSize: 7, fontWeight: 900, background: "#fff", display: "inline-flex", gap: 0 }}>
                  <span style={{ color: "#0E4C96" }}>J</span><span style={{ color: "#E60012" }}>C</span><span style={{ color: "#007B40" }}>B</span>
                </span>
              </div>
            </div>

            {/* Cardholder name */}
            <div style={{ borderBottom: "1px solid #f0f0f0" }}>
              <input
                type="text"
                value={card.holder}
                onChange={e => setCard(c => ({ ...c, holder: e.target.value }))}
                style={{ width: "100%", fontSize: 14, padding: "15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                placeholder="Cardholder name"
              />
            </div>

            {/* MM / YY  |  CVC — exactly as Stripe Elements reference */}
            <div className="flex">
              <div className="flex-1" style={{ borderRight: "1px solid #f0f0f0" }}>
                <input
                  type="text" inputMode="numeric"
                  value={card.expiry}
                  onChange={e => setCard(c => ({ ...c, expiry: formatExpiry(e.target.value) }))}
                  style={{ width: "100%", fontSize: 14, padding: "15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                  placeholder="MM / YY"
                />
              </div>
              <div className="flex-1 flex items-center">
                <input
                  type="text" inputMode="numeric" maxLength={4}
                  value={card.cvv}
                  onChange={e => setCard(c => ({ ...c, cvv: e.target.value.replace(/\D/g, "") }))}
                  style={{ flex: 1, fontSize: 14, padding: "15px 8px 15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                  placeholder="CVC"
                />
                {/* Card-back icon with "123" — exact Stripe Elements reference */}
                <svg width="26" height="18" viewBox="0 0 32 22" fill="none" className="mr-3 flex-shrink-0">
                  <rect x="1" y="1" width="30" height="20" rx="3" stroke="#bbb" strokeWidth="1.2" fill="white"/>
                  <rect x="1" y="5.5" width="30" height="5" fill="#ccc"/>
                  <rect x="18" y="13" width="9" height="4" rx="1" fill="#ddd"/>
                  <text x="22.5" y="16.4" textAnchor="middle" style={{ fontSize: 4.5, fontWeight: 700, fill: "#888" }}>123</text>
                </svg>
              </div>
            </div>
          </div>

          {/* Save card details toggle */}
          <div className="mx-3 mt-2.5 bg-white rounded-xl px-4 py-3.5 flex items-center justify-between"
            style={{ border: "1px solid #e8e8e8", boxShadow: "0 2px 15px rgba(0,0,0,0.04)" }}>
            <span style={{ fontSize: 13, fontWeight: 500, color: "#262626" }}>Save card details</span>
            <button type="button" onClick={() => setCard(c => ({ ...c, save: !c.save }))}
              className="relative flex-shrink-0"
              style={{ width: 44, height: 24, borderRadius: 12, background: card.save ? "#FF6900" : "#d1d5db", transition: "background 0.2s" }}>
              <span className="absolute top-1 w-5 h-5 bg-white rounded-full shadow"
                style={{ left: card.save ? 20 : 2, transition: "left 0.2s" }} />
            </button>
          </div>

          {/* ── Protection box — 100% AliExpress fidelity ── */}
          <div className="mx-3 mt-2.5 bg-white rounded-2xl p-4"
            style={{ border: "1px solid #e8e8e8", boxShadow: "0 1px 8px rgba(0,0,0,0.04)" }}>

            {/* Header: shield outline + bold text */}
            <div className="flex items-start gap-3 mb-3.5">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" className="flex-shrink-0 mt-0.5">
                <path d="M12 2L4 6v6c0 5.25 3.5 10.15 8 11.35C16.5 22.15 20 17.25 20 12V6L12 2z" stroke="#111" strokeWidth="1.6" strokeLinejoin="round"/>
                <path d="M9 12l2 2 4-4" stroke="#111" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span style={{ fontSize: 14, fontWeight: 700, color: "#111", lineHeight: 1.35 }}>
                ULTRA-X protects your payment information
              </span>
            </div>

            {/* 4 bullet points — green checkmarks, thin font */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
              {[
                "We follow the Payment Card Industry Data Security Standard (PCI DSS) when handing card data",
                "All information remains secure and uncompromised",
                "All data is encrypted",
                "Your card information will never be mishandled or sold",
              ].map(txt => (
                <div key={txt} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                  {/* Green checkmark — NOT a circle, just a checkmark like AliExpress */}
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: 1 }}>
                    <path d="M3 8l3 3 7-7" stroke="#3EAB61" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  <span style={{ fontSize: 12.5, color: "#333", lineHeight: 1.5, fontWeight: 400 }}>{txt}</span>
                </div>
              ))}
            </div>

            {/* ── Security badge row — 5 branded program tiles ── */}
            <div style={{ display: "flex", gap: 6, flexWrap: "nowrap", overflowX: "auto" }}>

              {/* VISA Secure */}
              <div style={{ flex: "0 0 auto", border: "1px solid #e0e0e0", borderRadius: 6, padding: "6px 8px", display: "flex", flexDirection: "column", alignItems: "center", minWidth: 52 }}>
                <div style={{ background: "#1A1F71", borderRadius: 3, padding: "1px 5px", marginBottom: 3 }}>
                  <span style={{ color: "white", fontSize: 8, fontWeight: 900, letterSpacing: "0.03em" }}>VISA</span>
                </div>
                <span style={{ fontSize: 7, color: "#555", fontWeight: 600, letterSpacing: "0.03em" }}>SECURE</span>
              </div>

              {/* Mastercard ID Check */}
              <div style={{ flex: "0 0 auto", border: "1px solid #e0e0e0", borderRadius: 6, padding: "5px 7px", display: "flex", alignItems: "center", gap: 4, minWidth: 72 }}>
                <span style={{ display: "inline-flex", alignItems: "center" }}>
                  <span style={{ width: 12, height: 12, borderRadius: "50%", background: "#EB001B", display: "inline-block", marginRight: -5 }} />
                  <span style={{ width: 12, height: 12, borderRadius: "50%", background: "#F79E1B", display: "inline-block" }} />
                </span>
                <span style={{ fontSize: 7.5, color: "#333", fontWeight: 600, lineHeight: 1.2 }}>ID<br/>Check</span>
              </div>

              {/* Amex SafeKey */}
              <div style={{ flex: "0 0 auto", border: "1px solid #e0e0e0", borderRadius: 6, padding: "5px 7px", display: "flex", alignItems: "center", gap: 4, minWidth: 66 }}>
                <div style={{ background: "#016FD0", borderRadius: 2, padding: "1px 3px" }}>
                  <span style={{ color: "white", fontSize: 7, fontWeight: 900 }}>AMEX</span>
                </div>
                <span style={{ fontSize: 7.5, color: "#333", fontWeight: 600, lineHeight: 1.2 }}>Safe<br/>Key™</span>
              </div>

              {/* Discover ProtectBuy */}
              <div style={{ flex: "0 0 auto", border: "1px solid #e0e0e0", borderRadius: 6, padding: "5px 7px", display: "flex", alignItems: "center", gap: 3, minWidth: 66 }}>
                <span style={{ fontSize: 8, fontWeight: 900, color: "#FF6000" }}>D</span>
                <span style={{ fontSize: 7, color: "#555", fontWeight: 600, lineHeight: 1.2 }}>Protect<br/>Buy</span>
              </div>

              {/* JCB J/Secure */}
              <div style={{ flex: "0 0 auto", border: "1px solid #e0e0e0", borderRadius: 6, padding: "5px 7px", display: "flex", alignItems: "center", gap: 4, minWidth: 56 }}>
                <div style={{ background: "#003087", borderRadius: 2, padding: "1px 3px" }}>
                  <span style={{ color: "white", fontSize: 7, fontWeight: 900 }}>JCB</span>
                </div>
                <span style={{ fontSize: 7, color: "#333", fontWeight: 600, lineHeight: 1.2 }}>J/<br/>Secure</span>
              </div>

            </div>
          </div>

          {/* Order totals */}
          <div className="mx-3 mt-2.5 bg-white rounded-xl px-4 py-3.5"
            style={{ border: "1px solid #e8e8e8", boxShadow: "0 2px 15px rgba(0,0,0,0.04)" }}>
            <div className="flex justify-between" style={{ fontSize: 12, color: "#888", marginBottom: 6 }}>
              <span>Subtotal</span><span dir="ltr">{format(totalPrice)}</span>
            </div>
            <div className="flex justify-between" style={{ fontSize: 12, color: "#888", marginBottom: 8 }}>
              <span>Shipping</span><span dir="ltr">{shippingCost === 0 ? "Free" : format(shippingCost)}</span>
            </div>
            <div className="flex justify-between" style={{ fontSize: 14, fontWeight: 600, color: "#262626", borderTop: "1px solid #f0f0f0", paddingTop: 8 }}>
              <span>Total</span><span dir="ltr">{format(grandTotal)}</span>
            </div>
          </div>

          {/* Sticky confirm bar */}
          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white px-3 py-2.5"
            style={{ borderTop: "1px solid #eee", boxShadow: "0 -4px 20px rgba(0,0,0,0.06)" }}>
            <button onClick={handlePay}
              className="w-full rounded-full flex items-center justify-center gap-2"
              style={{ background: "linear-gradient(180deg,#E63030 0%,#C82828 100%)", padding: "14px 0", boxShadow: "0 4px 16px rgba(200,40,40,0.32)" }}>
              <Lock style={{ width: 15, height: 15, color: "white" }} strokeWidth={2} />
              <span style={{ fontSize: 15, fontWeight: 600, color: "white", letterSpacing: "0.01em" }}>Save &amp; confirm</span>
            </button>
          </div>
        </div>
      )}

      {step === "payment-paymob" && (
        <div className="min-h-screen pb-36" style={{ background: "#f0f4f8" }}>

          {/* Blue gradient Paymob card */}
          <div className="pt-4">
            <PaymobCard number={card.number} holder={card.holder} expiry={card.expiry} />
          </div>

          {/* White form card — matches Paymob reference exactly */}
          <div className="mx-3 mt-1 bg-white rounded-2xl overflow-hidden"
            style={{ border: "1px solid #e0e8f0", boxShadow: "0 4px 20px rgba(0,0,0,0.07)" }}>

            {/* Card Number + icons */}
            <div className="relative" style={{ borderBottom: "1px solid #f0f0f0" }}>
              <input type="text" inputMode="numeric"
                value={card.number}
                onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))}
                style={{ width: "100%", fontSize: 15, padding: "15px 120px 15px 16px", background: "transparent", outline: "none", color: "#262626", letterSpacing: "0.05em" }}
                placeholder="Card Number"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                <div style={{ background: "linear-gradient(135deg,#b00000,#e00000)", borderRadius: 4, padding: "2px 6px", fontSize: 9, fontWeight: 800, color: "white", fontStyle: "italic" }}>
                  ميزة
                </div>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <span style={{ width: 15, height: 15, borderRadius: "50%", background: "#EB001B", display: "inline-block", marginRight: -7 }} />
                  <span style={{ width: 15, height: 15, borderRadius: "50%", background: "#F79E1B", display: "inline-block" }} />
                </div>
                <div style={{ border: "1px solid #d0d5e0", borderRadius: 3, padding: "2px 5px", background: "white" }}>
                  <span style={{ fontSize: 9.5, fontWeight: 900, color: "#1A1F71" }}>VISA</span>
                </div>
              </div>
            </div>

            {/* Card Holder Name */}
            <div style={{ borderBottom: "1px solid #f0f0f0" }}>
              <input type="text"
                value={card.holder}
                onChange={e => setCard(c => ({ ...c, holder: e.target.value }))}
                style={{ width: "100%", fontSize: 14, padding: "15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                placeholder="Card Holder Name"
              />
            </div>

            {/* MM/YY | CVV */}
            <div className="flex" style={{ borderBottom: "1px solid #f0f0f0" }}>
              <div style={{ flex: 1, borderRight: "1px solid #f0f0f0" }}>
                <input type="text" inputMode="numeric"
                  value={card.expiry}
                  onChange={e => setCard(c => ({ ...c, expiry: formatExpiry(e.target.value) }))}
                  style={{ width: "100%", fontSize: 14, padding: "15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                  placeholder="MM/YY"
                />
              </div>
              <div style={{ flex: 1 }}>
                <input type="text" inputMode="numeric" maxLength={4}
                  value={card.cvv}
                  onChange={e => setCard(c => ({ ...c, cvv: e.target.value.replace(/\D/g, "") }))}
                  style={{ width: "100%", fontSize: 14, padding: "15px 16px", background: "transparent", outline: "none", color: "#262626" }}
                  placeholder="CVV"
                />
              </div>
            </div>

            {/* Save Card checkbox */}
            <label className="flex items-center gap-2.5 cursor-pointer px-4 py-3.5">
              <input type="checkbox" checked={card.save}
                onChange={e => setCard(c => ({ ...c, save: e.target.checked }))}
                style={{ width: 15, height: 15, accentColor: "#1565c0" }}
              />
              <span style={{ fontSize: 13, color: "#555" }}>Save Card</span>
            </label>
          </div>

          {/* Pay button */}
          <div className="mx-3 mt-4">
            <button onClick={handlePay}
              className="w-full rounded-xl flex items-center justify-center gap-2"
              style={{ background: "linear-gradient(180deg,#1E88E5 0%,#1565C0 100%)", padding: "15px 0", boxShadow: "0 4px 18px rgba(21,101,192,0.35)" }}>
              <Lock style={{ width: 15, height: 15, color: "white" }} strokeWidth={2} />
              <span style={{ fontSize: 15, fontWeight: 600, color: "white" }}>Pay {format(grandTotal)} EGP</span>
            </button>
            <div className="flex items-center justify-center gap-1.5 mt-2">
              <Lock style={{ width: 11, height: 11, color: "#999" }} strokeWidth={2} />
              <span style={{ fontSize: 11, color: "#999" }}>Secured by Paymob</span>
            </div>
          </div>

          {/* Paymob logo + bank logos — pixel-perfect brand fidelity */}
          <div className="mx-3 mt-4 bg-white rounded-2xl overflow-hidden"
            style={{ border: "1px solid #e0e8f0", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>

            {/* Official Paymob wordmark */}
            <div className="flex justify-center items-center py-4" style={{ borderBottom: "1px solid #f0f4f8" }}>
              <img src="/paymob-logo.jpg" alt="paymob" style={{ height: 36, objectFit: "contain", borderRadius: 4 }} />
            </div>

            {/* ── 4-bank logo row — brand-accurate colors & typography ── */}
            <div style={{ display: "flex", alignItems: "stretch", justifyContent: "space-around", padding: "14px 8px", gap: 6 }}>

              {/* Banque Misr — gold/amber brand color */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, border: "1px solid #e8dcc8", background: "white", boxShadow: "0 1px 5px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 1 }}>
                  {/* Gold torch/star mark */}
                  <div style={{ width: 20, height: 20, borderRadius: "50%", background: "radial-gradient(circle,#d4a017 0%,#b8860b 100%)", border: "2px solid #c9960f", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ fontSize: 8, color: "white", fontWeight: 900 }}>★</span>
                  </div>
                  <span style={{ fontSize: 7.5, fontWeight: 800, color: "#9a6500", letterSpacing: "-0.5px", fontFamily: "serif" }}>بنك</span>
                </div>
                <span style={{ fontSize: 8.5, color: "#444", fontWeight: 600, textAlign: "center", lineHeight: 1.2 }}>Banque<br/>Misr</span>
              </div>

              {/* Al Mashriq (المشرق) — deep blue brand color */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, border: "1px solid #d0dff0", background: "white", boxShadow: "0 1px 5px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 1 }}>
                  <svg width="18" height="10" viewBox="0 0 20 11" fill="none">
                    <path d="M1 10 Q5 1 10 5 Q15 10 19 1" stroke="#1a5fba" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
                  </svg>
                  <span style={{ fontSize: 8.5, fontWeight: 700, color: "#1a5fba" }}>المشرق</span>
                </div>
                <span style={{ fontSize: 8.5, color: "#444", fontWeight: 600, textAlign: "center", lineHeight: 1.2 }}>Al<br/>Mashriq</span>
              </div>

              {/* CIB — brand blue with brackets */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, border: "1px solid #cce0f5", background: "white", boxShadow: "0 1px 5px rgba(0,0,0,0.06)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ background: "#00529b", borderRadius: 5, padding: "4px 7px", display: "flex", alignItems: "center", gap: 0 }}>
                    <span style={{ color: "white", fontSize: 13, fontWeight: 900, letterSpacing: "0.04em", fontFamily: "Arial, sans-serif" }}>CIB</span>
                  </div>
                </div>
                <span style={{ fontSize: 8.5, color: "#444", fontWeight: 600 }}>CIB</span>
              </div>

              {/* NBE — National Bank of Egypt, green circular seal */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, border: "1px solid #cce8d5", background: "white", boxShadow: "0 1px 5px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 1 }}>
                  <div style={{ width: 24, height: 24, borderRadius: "50%", background: "linear-gradient(135deg,#006b3c,#008c4e)", border: "1.5px solid #00793f", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ fontSize: 7.5, fontWeight: 900, color: "white", letterSpacing: "0.02em" }}>NBE</span>
                  </div>
                  <span style={{ fontSize: 6, color: "#006b3c", fontWeight: 600, letterSpacing: "-0.3px" }}>الأهلي</span>
                </div>
                <span style={{ fontSize: 8.5, color: "#444", fontWeight: 600, textAlign: "center", lineHeight: 1.2 }}>National<br/>Bank</span>
              </div>

            </div>
          </div>

          <div style={{ height: 80 }} />
        </div>
      )}
    </StoreLayout>
  );
};

export default Checkout;
