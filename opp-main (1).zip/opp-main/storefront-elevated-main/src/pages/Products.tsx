import { useSearchParams, Link } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import ProductCard from "@/components/store/ProductCard";
import ProductCardSkeleton from "@/components/store/ProductCardSkeleton";
import { useProducts, useCategories } from "@/hooks/useProducts";
import { useMemo, useState } from "react";

const Products = () => {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get("search") || "";
  const categoryFilter = searchParams.get("category") || "";
  const [selectedCat, setSelectedCat] = useState<string | null>(categoryFilter || null);
  const { products, loading } = useProducts();
  const categories = useCategories();

  const filtered = useMemo(() => {
    let result = [...products];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q)
      );
    }
    const cat = selectedCat || categoryFilter;
    if (cat) result = result.filter(p => p.category === cat);
    return result;
  }, [searchQuery, categoryFilter, selectedCat, products]);

  return (
    <StoreLayout>
      {/* Slim header bar */}
      <div
        className="bg-white flex items-center justify-between sticky top-0 z-10"
        style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}
      >
        <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: "-0.02em", color: "#0A1F44" }}>
          ULTRA-X <span style={{ color: "#E53935" }}>STORE</span>
        </span>
        <span style={{ fontSize: 10.5, color: "#bbb" }}>{filtered.length} products</span>
      </div>

      {/* ── Dual-panel layout: narrow sidebar LEFT, products RIGHT ── */}
      <div className="flex" style={{ height: "calc(100vh - 110px)" }}>

        {/* LEFT: Professional category sidebar */}
        <div
          style={{
            width: 72,
            flexShrink: 0,
            background: "#f7f7f7",
            borderRight: "1px solid #ececec",
            overflowY: "auto",
            overscrollBehavior: "contain",
          }}
          className="hide-scrollbar"
        >
          {/* All */}
          <button
            onClick={() => setSelectedCat(null)}
            style={{
              width: "100%",
              padding: "12px 6px 10px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 5,
              background: !selectedCat ? "#fff" : "transparent",
              borderLeft: !selectedCat ? "2.5px solid #E53935" : "2.5px solid transparent",
              borderBottom: "1px solid #ececec",
            }}
          >
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 8,
                background: !selectedCat ? "#fff0f0" : "#ebebeb",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 16,
              }}
            >
              🛍
            </div>
            <span
              style={{
                fontSize: 9.5,
                fontWeight: !selectedCat ? 600 : 400,
                color: !selectedCat ? "#E53935" : "#666",
                textAlign: "center",
                lineHeight: 1.2,
              }}
            >
              All
            </span>
          </button>

          {/* Category entries */}
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              style={{
                width: "100%",
                padding: "10px 6px 9px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 4,
                background: selectedCat === cat.id ? "#fff" : "transparent",
                borderLeft: selectedCat === cat.id ? "2.5px solid #E53935" : "2.5px solid transparent",
                borderBottom: "1px solid #ececec",
              }}
            >
              {/* Category thumbnail from first matching product */}
              <div
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 8,
                  overflow: "hidden",
                  background: "#e8e8e8",
                  border: selectedCat === cat.id ? "1.5px solid #E53935" : "1px solid #ddd",
                }}
              >
                {(() => {
                  const thumb = products.find(p => p.category === cat.id);
                  return thumb ? (
                    <img
                      src={thumb.image}
                      alt={cat.name}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "100%", background: "#e0e0e0" }} />
                  );
                })()}
              </div>
              <span
                style={{
                  fontSize: 9,
                  fontWeight: selectedCat === cat.id ? 600 : 400,
                  color: selectedCat === cat.id ? "#E53935" : "#666",
                  textAlign: "center",
                  lineHeight: 1.2,
                  maxWidth: 60,
                  overflow: "hidden",
                  display: "-webkit-box",
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: "vertical",
                }}
              >
                {cat.name}
              </span>
            </button>
          ))}
        </div>

        {/* RIGHT: Large square product grid */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            background: "#f5f5f5",
            overscrollBehavior: "contain",
          }}
        >
          {/* Section label */}
          <div
            style={{
              background: "#f5f5f5",
              padding: "8px 10px 6px",
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <span style={{ fontSize: 11, fontWeight: 600, color: "#111" }}>
              {selectedCat
                ? categories.find(c => c.id === selectedCat)?.name
                : "Recommended"}
            </span>
            <div style={{ flex: 1, height: 1, background: "#e0e0e0" }} />
          </div>

          {/* 2-column grid — fills full right-panel width */}
          {loading ? (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}>
              {Array.from({ length: 8 }).map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", paddingTop: 60 }}>
              <p style={{ fontSize: 12, color: "#bbb" }}>No products found</p>
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 2,
                paddingBottom: 150,
              }}
            >
              {filtered.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </StoreLayout>
  );
};

export default Products;
