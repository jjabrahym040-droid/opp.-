import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useAuth } from "@/contexts/AuthContext";
import { lovable } from "@/integrations/lovable/index";
import { toast } from "sonner";
import { Mail, ChevronLeft } from "lucide-react";

const Auth = () => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [sending, setSending] = useState(false);
  const { user, sendOtp, verifyOtp } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate("/account", { replace: true });
  }, [user, navigate]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) { toast.error("يرجى إدخال البريد الإلكتروني"); return; }
    setSending(true);
    const res = await sendOtp(email);
    setSending(false);
    if (res.ok) {
      setOtpSent(true);
      toast.success("تم إرسال رمز التأكيد إلى بريدك الإلكتروني");
    } else {
      toast.error(res.error || "حدث خطأ أثناء إرسال رمز التأكيد");
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp) { toast.error("يرجى إدخال رمز التأكيد"); return; }
    setSending(true);
    const res = await verifyOtp(email, otp);
    setSending(false);
    if (res.ok) {
      toast.success("تم تسجيل الدخول بنجاح!");
      // navigation handled by useEffect on `user`
    } else {
      toast.error(res.error || "رمز التأكيد غير صحيح");
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin + "/account",
      });
      if (result.error) {
        toast.error("فشل تسجيل الدخول بـ Google");
        return;
      }
      // Either browser will redirect to Google, or session is set automatically.
      // Don't navigate manually — the useEffect on `user` handles routing.
    } catch {
      toast.error("حدث خطأ أثناء تسجيل الدخول");
    }
  };

  if (user) return null;

  return (
    <StoreLayout hideHeader>
      {/* Header */}
      <div className="bg-white px-3 py-2.5 flex items-center gap-2 border-b border-[#eee]">
        <button onClick={() => navigate(-1)}>
          <ChevronLeft className="w-5 h-5 text-[#191919]" strokeWidth={1.5} />
        </button>
        <div>
          <span className="text-sm font-bold" style={{ color: '#E53935' }}>Shop</span>
          <span className="text-sm font-bold text-[#191919]">Zone</span>
          <span className="text-xs text-[#999] block -mt-0.5">تسجيل الدخول</span>
        </div>
      </div>

      <div className="px-4 py-8 max-w-sm mx-auto">
        {/* Logo */}
        <div className="text-center mb-8">
          <span className="text-4xl font-black" style={{ color: '#E53935' }}>Shop</span>
          <span className="text-4xl font-black text-[#191919]">Zone</span>
          <p className="text-xs text-[#999] mt-1">تسوق بذكاء، وفر أكثر</p>
        </div>

        <div className="bg-white rounded-2xl border border-[#eee] p-5">
          <h2 className="text-base font-bold text-[#191919] text-center mb-5">تسجيل الدخول / إنشاء حساب</h2>

          {!otpSent ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#bbb]" strokeWidth={1.5} />
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-10 pr-3 py-3.5 border border-[#e0e0e0] rounded-xl bg-[#fafafa] text-sm focus:outline-none focus:border-[#E53935] text-right transition-colors"
                    placeholder="أدخل بريدك الإلكتروني"
                    dir="rtl"
                  />
                </div>
                <p className="text-[10px] text-[#4CAF50] mt-1.5 text-right">
                  سيتم إرسال رمز تأكيد إلى بريدك الإلكتروني
                </p>
              </div>
              <button
                type="submit"
                disabled={sending}
                className="w-full py-3.5 rounded-xl text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                style={{ backgroundColor: '#FF6000' }}
              >
                {sending ? "جاري الإرسال..." : "إرسال رمز التأكيد"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <p className="text-xs text-[#666] text-center mb-2">
                تم إرسال رمز التأكيد إلى <span className="font-bold text-[#191919]">{email}</span>
              </p>
              <input
                type="text"
                value={otp}
                onChange={e => setOtp(e.target.value)}
                className="w-full px-3 py-3.5 border border-[#e0e0e0] rounded-xl bg-[#fafafa] text-center text-lg font-bold tracking-[0.5em] focus:outline-none focus:border-[#E53935] transition-colors"
                placeholder="• • • • • •"
                maxLength={6}
                inputMode="numeric"
              />
              <button
                type="submit"
                disabled={sending}
                className="w-full py-3.5 rounded-xl text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                style={{ backgroundColor: '#FF6000' }}
              >
                {sending ? "جاري التحقق..." : "تأكيد"}
              </button>
              <button
                type="button"
                onClick={() => { setOtpSent(false); setOtp(""); }}
                className="w-full text-xs text-[#999] py-2"
              >
                تغيير البريد الإلكتروني
              </button>
            </form>
          )}

          {/* Divider */}
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[#e0e0e0]" />
            <span className="text-[10px] text-[#999]">أو</span>
            <div className="flex-1 h-px bg-[#e0e0e0]" />
          </div>

          {/* Google sign in */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            className="w-full py-3.5 rounded-xl text-sm font-semibold text-[#333] bg-white border border-[#e0e0e0] flex items-center justify-center gap-2.5 hover:bg-[#fafafa] transition-colors"
          >
            <svg width="20" height="20" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            تسجيل باستخدام Google
          </button>
        </div>
      </div>
    </StoreLayout>
  );
};

export default Auth;
