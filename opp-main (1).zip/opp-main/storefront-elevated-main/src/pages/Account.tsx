import { Link, useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useAuth } from "@/contexts/AuthContext";
import { Settings, Heart, Gift, Ticket, CreditCard, Package, Truck, CheckCircle, Search, ChevronLeft, ChevronRight, Clock, DollarSign } from "lucide-react";
import { useEffect } from "react";
import { useProducts } from "@/hooks/useProducts";

const Account = () => {
  const { user, loading, logout } = useAuth();
  const { products } = useProducts();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) navigate("/auth", { replace: true });
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <StoreLayout hideHeader>
        <div className="flex items-center justify-center min-h-screen">
          <div className="w-8 h-8 border-2 border-[#E53935] border-t-transparent rounded-full animate-spin" />
        </div>
      </StoreLayout>
    );
  }

  if (!user) return null;

  const mockOrders = [
    {
      id: "ORD-001",
      date: "1 أبر 2026",
      total: 230.65,
      status: "To pay",
      items: 1,
      image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&h=200&fit=crop",
      name: "أداة ضبط حزام الساعة أداة إصلاح الساعة مع...",
      material: "plactic",
    },
  ];

  const orderStatuses = [
    { icon: CreditCard, label: "قيد انتظار الدفع", count: 1, color: "#E53935" },
    { icon: Package, label: "قيد الشحن", count: 0, color: "#FF6000" },
    { icon: Truck, label: "مشحونة", count: 0, color: "#FF6000" },
    { icon: CheckCircle, label: "للمراجعة", count: 0, color: "#FF6000" },
  ];

  const recentlyViewed = products.slice(0, 6);

  return (
    <StoreLayout hideHeader>
      {/* Header */}
      <div className="bg-white px-3 py-2.5 flex items-center justify-between border-b border-[#eee]">
        <div className="flex items-center gap-2">
          <button onClick={() => navigate(-1)}>
            <ChevronLeft className="w-5 h-5 text-[#191919]" strokeWidth={1.5} />
          </button>
          <div>
            <span className="text-sm font-extrabold text-[#191919]">AliExpress</span>
            <span className="text-xs text-[#999] block -mt-0.5">الحساب</span>
          </div>
        </div>
        <Search className="w-5 h-5 text-[#191919]" strokeWidth={1.5} />
      </div>

      {/* Profile card */}
      <div className="bg-white px-4 pt-6 pb-4">
        <div className="flex items-center gap-3 justify-end">
          <div className="text-right">
            <div className="font-bold text-lg text-[#191919]">{user.name}</div>
          </div>
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white"
            style={{ backgroundColor: '#E53935' }}
          >
            {user.name.charAt(0).toUpperCase()}
          </div>
        </div>

        {/* Quick links */}
        <div className="grid grid-cols-3 gap-3 mt-6">
          {[
            { icon: Heart, label: "قائمة الأمنيات" },
            { icon: Ticket, label: "الكوبونات" },
            { icon: DollarSign, label: "نقاط التسوق" },
          ].map(item => (
            <button key={item.label} className="flex flex-col items-center gap-2 py-3 rounded-xl hover:bg-[#fafafa] transition-colors">
              <item.icon className="w-6 h-6 text-[#191919]" strokeWidth={1.5} />
              <span className="text-xs text-[#191919] font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Orders section */}
      <div className="bg-white mt-2.5">
        <div className="px-4 py-3.5 flex items-center justify-between">
          <Link to="/products" className="text-xs text-[#999] flex items-center gap-0.5">
            <ChevronRight className="w-3.5 h-3.5" strokeWidth={1.5} />
            عرض الكل
          </Link>
          <h2 className="text-base font-bold text-[#191919]">الطلبات</h2>
        </div>
        <div className="h-px bg-[#eee]" />

        {/* Order status grid */}
        <div className="grid grid-cols-4 py-5">
          {orderStatuses.map(status => (
            <button key={status.label} className="flex flex-col items-center gap-2.5 relative">
              <div className="relative">
                <status.icon className="w-8 h-8" style={{ color: status.color }} strokeWidth={1.5} />
                {status.count > 0 && (
                  <span
                    className="absolute -top-1 -right-1 w-4.5 h-4.5 rounded-full text-[9px] font-bold flex items-center justify-center text-white min-w-[18px] min-h-[18px]"
                    style={{ backgroundColor: '#E53935' }}
                  >
                    {status.count}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-[#191919] font-medium">{status.label}</span>
            </button>
          ))}
        </div>

        {/* Recent order card */}
        {mockOrders.map(order => (
          <div key={order.id} className="px-4 py-4 border-t border-[#eee]" style={{ backgroundColor: '#fafafa' }}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1 text-xs text-[#999]">
                <ChevronRight className="w-3 h-3" strokeWidth={1.5} />
                <span>{order.date}</span>
              </div>
              <span className="text-sm font-bold text-[#191919]">{order.status}</span>
            </div>
            <div className="flex gap-3">
              <div className="flex-1 text-right">
                <p className="text-sm text-[#191919] leading-relaxed font-medium">{order.name}</p>
                <div className="text-xs text-[#999] mt-1">{order.material}</div>
                <div className="flex items-center justify-end gap-2 mt-1">
                  <span className="text-xs text-[#999]">x1</span>
                  <span className="text-sm font-bold text-[#191919]">EGP {order.total}</span>
                </div>
                <div className="mt-2">
                  <p className="text-base font-extrabold text-[#191919]">Total: EGP {order.total}</p>
                </div>
                <button
                  className="mt-3 text-sm font-bold px-8 py-2.5 rounded-full text-white"
                  style={{ backgroundColor: '#E53935' }}
                >
                  Pay now
                </button>
              </div>
              <img src={order.image} alt="" className="w-24 h-24 rounded-xl object-cover flex-shrink-0" />
            </div>
          </div>
        ))}
      </div>

      {/* Refunds section */}
      <div className="bg-white mt-2.5 px-4 py-3.5 flex items-center justify-end gap-2">
        <span className="text-sm text-[#191919] font-medium">استرداد الأموال والإرجاع</span>
        <DollarSign className="w-5 h-5 text-[#FF6000]" strokeWidth={1.5} />
      </div>

      {/* Recently viewed */}
      <div className="bg-white mt-2.5">
        <div className="px-4 py-3.5 flex items-center justify-between">
          <Link to="/products" className="text-xs text-[#999] flex items-center gap-0.5">
            <ChevronRight className="w-3.5 h-3.5" strokeWidth={1.5} />
            عرض الكل
          </Link>
          <h2 className="text-sm font-bold text-[#191919] flex items-center gap-1.5">
            سجل التصفح
            <Clock className="w-4 h-4 text-[#999]" strokeWidth={1.5} />
          </h2>
        </div>
        <div className="px-3 pb-4 flex gap-2.5 overflow-x-auto hide-scrollbar">
          {recentlyViewed.map(p => (
            <Link key={p.id} to={`/product/${p.id}`} className="flex-shrink-0 w-28">
              <div className="w-28 h-28 rounded-xl overflow-hidden bg-[#f5f5f5]">
                <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              </div>
              <p className="text-[11px] text-[#191919] mt-1.5 line-clamp-1 font-medium">{p.name}</p>
              <p className="text-xs font-extrabold" style={{ color: '#E53935' }}>{p.price} ج.م</p>
            </Link>
          ))}
        </div>
      </div>

      {/* Settings & logout */}
      <div className="bg-white mt-2.5">
        <Link to="/settings" className="flex items-center gap-2 px-4 py-3.5 border-b border-[#eee] text-sm font-medium text-[#191919]">
          <ChevronRight className="w-4 h-4 text-[#999]" strokeWidth={1.5} />
          <span className="flex-1 text-right">الإعدادات</span>
          <Settings className="w-5 h-5 text-[#999]" strokeWidth={1.5} />
        </Link>
        <button
          onClick={async () => { await logout(); navigate("/"); }}
          className="flex items-center justify-center gap-2 px-4 py-3.5 text-sm w-full font-bold"
          style={{ color: '#E53935' }}
        >
          تسجيل الخروج
        </button>
      </div>

      <div className="h-20" />
    </StoreLayout>
  );
};

export default Account;
