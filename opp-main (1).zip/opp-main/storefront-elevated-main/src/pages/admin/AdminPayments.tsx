import AdminLayout from "@/components/admin/AdminLayout";

const payments = [
  { id: "PAY-001", orderId: "ORD-101", customer: "أحمد محمد", email: "ahmed@email.com", amount: 548, method: "Stripe", status: "مكتمل", date: "2026-03-07" },
  { id: "PAY-002", orderId: "ORD-100", customer: "سارة علي", email: "sara@email.com", amount: 1299, method: "PayPal", status: "مكتمل", date: "2026-03-06" },
  { id: "PAY-003", orderId: "ORD-099", customer: "محمود حسن", email: "mahmoud@email.com", amount: 228, method: "Stripe", status: "مكتمل", date: "2026-03-05" },
  { id: "PAY-004", orderId: "ORD-098", customer: "فاطمة يوسف", email: "fatma@email.com", amount: 899, method: "PayPal", status: "معلق", date: "2026-03-04" },
  { id: "PAY-005", orderId: "ORD-097", customer: "عمر خالد", email: "omar@email.com", amount: 349, method: "Stripe", status: "مسترد", date: "2026-03-03" },
];

const AdminPayments = () => (
  <AdminLayout>
    <h1 className="text-2xl font-bold mb-6">المدفوعات</h1>

    {/* Summary Cards */}
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="text-sm text-muted-foreground">إجمالي المدفوعات</div>
        <div className="text-2xl font-bold store-success">3,323 ج.م</div>
      </div>
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="text-sm text-muted-foreground">معلقة</div>
        <div className="text-2xl font-bold text-store-accent">899 ج.م</div>
      </div>
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="text-sm text-muted-foreground">مستردة</div>
        <div className="text-2xl font-bold store-deal">349 ج.م</div>
      </div>
    </div>

    <div className="bg-card rounded-lg border border-border overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="text-right p-3">رقم الدفعة</th>
            <th className="text-right p-3">رقم الطلب</th>
            <th className="text-right p-3">العميل</th>
            <th className="text-right p-3">البريد</th>
            <th className="text-right p-3">المبلغ</th>
            <th className="text-right p-3">الطريقة</th>
            <th className="text-right p-3">الحالة</th>
            <th className="text-right p-3">التاريخ</th>
          </tr>
        </thead>
        <tbody>
          {payments.map(p => (
            <tr key={p.id} className="border-b border-border hover:bg-muted/50">
              <td className="p-3 font-semibold">{p.id}</td>
              <td className="p-3">{p.orderId}</td>
              <td className="p-3">{p.customer}</td>
              <td className="p-3 text-muted-foreground">{p.email}</td>
              <td className="p-3 font-semibold">{p.amount.toLocaleString()} ج.م</td>
              <td className="p-3"><span className="text-xs bg-muted px-2 py-0.5 rounded">{p.method}</span></td>
              <td className="p-3">
                <span className={`text-xs px-2 py-1 rounded-full ${
                  p.status === "مكتمل" ? "bg-green-100 text-green-700" :
                  p.status === "معلق" ? "bg-yellow-100 text-yellow-700" :
                  "bg-red-100 text-red-700"
                }`}>{p.status}</span>
              </td>
              <td className="p-3 text-muted-foreground">{p.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </AdminLayout>
);

export default AdminPayments;
