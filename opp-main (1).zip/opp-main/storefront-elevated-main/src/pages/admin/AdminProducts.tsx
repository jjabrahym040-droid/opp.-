import AdminLayout from "@/components/admin/AdminLayout";
import { useEffect, useState } from "react";
import { Plus, Edit, Trash2, X, Upload, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface ProductRow {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  images: string[];
}

const emptyForm = { id: "", name: "", description: "", price: "" };

const AdminProducts = () => {
  const [productList, setProductList] = useState<ProductRow[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });
  const [thumbnail, setThumbnail] = useState<string>(""); // main image
  const [gallery, setGallery] = useState<string[]>([]);  // additional images
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    if (error) { toast.error("Failed to load products"); return; }
    setProductList((data || []) as ProductRow[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const ch = supabase.channel("admin-products")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const resetForm = () => { setForm({ ...emptyForm }); setThumbnail(""); setGallery([]); };
  const openNew = () => { resetForm(); setShowForm(true); };

  const openEdit = (p: ProductRow) => {
    setForm({ id: p.id, name: p.name, description: p.description || "", price: String(p.price) });
    setThumbnail(p.image);
    setGallery((p.images || []).filter(u => u !== p.image));
    setShowForm(true);
  };

  const preloadImage = (url: string) =>
    new Promise<boolean>((resolve) => {
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = url;
      // safety timeout
      setTimeout(() => resolve(false), 8000);
    });

  const uploadFiles = async (files: FileList | null): Promise<string[]> => {
    if (!files || files.length === 0) return [];
    setUploading(true);
    const out: string[] = [];
    for (const file of Array.from(files)) {
      // Accept ALL image formats including AVIF, HEIC, WEBP, etc.
      const isImage = file.type.startsWith("image/") || /\.(jpe?g|png|webp|avif|heic|heif|gif|bmp|svg)$/i.test(file.name);
      if (!isImage) {
        toast.error(`Not an image: ${file.name}`);
        continue;
      }
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`Too large: ${file.name} (max 10MB)`);
        continue;
      }
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${crypto.randomUUID()}.${ext}`;
      const contentType = file.type || `image/${ext === "jpg" ? "jpeg" : ext}`;
      const { error } = await supabase.storage
        .from("product-images")
        .upload(path, file, { cacheControl: "3600", upsert: false, contentType });
      if (error) { toast.error(`Upload failed: ${error.message}`); continue; }
      const { data: pub } = supabase.storage.from("product-images").getPublicUrl(path);
      out.push(pub.publicUrl);
    }
    setUploading(false);
    return out;
  };

  const handleThumbnailUpload = async (files: FileList | null) => {
    if (files && files[0]) {
      // instant local preview
      const localUrl = URL.createObjectURL(files[0]);
      setThumbnail(localUrl);
    }
    const urls = await uploadFiles(files);
    if (urls[0]) { setThumbnail(urls[0]); toast.success("Thumbnail uploaded"); }
    else if (files && files[0]) setThumbnail(""); // upload failed, clear preview
  };

  const handleGalleryUpload = async (files: FileList | null) => {
    if (files) {
      const previews = Array.from(files).map(f => URL.createObjectURL(f));
      setGallery(prev => [...prev, ...previews]);
    }
    const urls = await uploadFiles(files);
    if (urls.length) {
      // replace blob: previews with public URLs (drop the blob ones we just added)
      const dropCount = files ? files.length : 0;
      setGallery(prev => [...prev.slice(0, prev.length - dropCount), ...urls]);
      toast.success(`${urls.length} image(s) added`);
    } else if (files) {
      // upload failed, drop the blob previews
      setGallery(prev => prev.slice(0, prev.length - files.length));
    }
  };

  const removeGallery = (i: number) => setGallery(prev => prev.filter((_, idx) => idx !== i));

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this product?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) { toast.error("Delete failed: " + error.message); return; }
    toast.success("Product deleted");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.price || !thumbnail) {
      toast.error("Name, price, and thumbnail are required");
      return;
    }
    setSaving(true);
    const allImages = [thumbnail, ...gallery];
    const payload = {
      name: form.name.trim(),
      description: form.description.trim(),
      price: Number(form.price),
      image: thumbnail,
      images: allImages,
    };
    let error;
    if (form.id) {
      ({ error } = await supabase.from("products").update(payload).eq("id", form.id));
    } else {
      ({ error } = await supabase.from("products").insert(payload));
    }
    setSaving(false);
    if (error) { toast.error("Save failed: " + error.message); return; }
    toast.success(form.id ? "Product updated" : "Product published");
    setShowForm(false); resetForm();
  };

  const inputClass = "w-full px-3 py-2.5 border border-[#ddd] rounded-md bg-white text-sm focus:outline-none focus:border-[#0A1F44]";

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-lg font-semibold text-[#0A1F44]">Products ({productList.length})</h1>
        <button onClick={openNew} className="px-4 py-2 text-sm font-medium text-white rounded-md flex items-center gap-2 bg-[#0A1F44] hover:bg-[#1565C0]">
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-5 max-w-lg w-full max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-base text-[#0A1F44]">{form.id ? "Edit Product" : "New Product"}</h2>
              <button onClick={() => { setShowForm(false); resetForm(); }}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* 1. Thumbnail */}
              <div>
                <label className="text-xs font-medium text-[#333] block mb-1.5">1. Thumbnail Image *</label>
                {thumbnail ? (
                  <div className="relative w-32 h-32">
                    <img src={thumbnail} alt="" className="w-full h-full object-cover rounded-md border border-[#ddd]" />
                    <button type="button" onClick={() => setThumbnail("")} className="absolute -top-2 -right-2 w-6 h-6 bg-[#0A1F44] text-white rounded-full flex items-center justify-center">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 border border-dashed border-[#0A1F44]/40 rounded-md p-4 cursor-pointer hover:bg-[#F5F8FF]">
                    <Upload className="w-4 h-4 text-[#0A1F44]" />
                    <span className="text-sm text-[#0A1F44]">{uploading ? "Uploading..." : "Choose from gallery"}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={e => handleThumbnailUpload(e.target.files)} disabled={uploading} />
                  </label>
                )}
              </div>

              {/* 2. Gallery images */}
              <div>
                <label className="text-xs font-medium text-[#333] block mb-1.5">2. Gallery Images (optional)</label>
                <label className="flex items-center justify-center gap-2 border border-dashed border-[#ddd] rounded-md p-3 cursor-pointer hover:bg-[#fafafa]">
                  <Upload className="w-4 h-4 text-[#666]" />
                  <span className="text-sm text-[#666]">{uploading ? "Uploading..." : "Add gallery images"}</span>
                  <input type="file" accept="image/*" multiple className="hidden" onChange={e => handleGalleryUpload(e.target.files)} disabled={uploading} />
                </label>
                {gallery.length > 0 && (
                  <div className="grid grid-cols-4 gap-2 mt-2">
                    {gallery.map((url, i) => (
                      <div key={i} className="relative aspect-square">
                        <img src={url} alt="" className="w-full h-full object-cover rounded-md border border-[#ddd]" />
                        <button type="button" onClick={() => removeGallery(i)} className="absolute -top-1 -right-1 w-5 h-5 bg-[#0A1F44] text-white rounded-full flex items-center justify-center">
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 3. Name + description */}
              <div>
                <label className="text-xs font-medium text-[#333] block mb-1">3. Product Name *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={inputClass} />
              </div>
              <div>
                <label className="text-xs font-medium text-[#333] block mb-1">Description</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className={inputClass} rows={3} />
              </div>

              {/* 4. Price */}
              <div>
                <label className="text-xs font-medium text-[#333] block mb-1">4. Price (USD) *</label>
                <input type="number" step="0.01" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} className={inputClass} />
              </div>

              <button type="submit" disabled={saving || uploading} className="w-full py-2.5 text-sm font-medium text-white rounded-md disabled:opacity-50 bg-[#0A1F44] hover:bg-[#1565C0]">
                {saving ? "Saving..." : (form.id ? "Save Changes" : "Publish Product")}
              </button>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-sm text-[#666]">Loading...</div>
      ) : productList.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-md border border-dashed border-[#ddd]">
          <ImageIcon className="w-12 h-12 mx-auto text-[#ccc] mb-3" />
          <p className="text-sm font-medium text-[#191919]">No products yet</p>
          <p className="text-xs text-[#666] mt-1">Click "Add Product" to start</p>
        </div>
      ) : (
        <div className="bg-white rounded-md border border-[#eee] overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#eee] text-[#666]">
                <th className="text-left p-3 text-xs font-medium">Product</th>
                <th className="text-left p-3 text-xs font-medium">Price</th>
                <th className="text-left p-3 text-xs font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {productList.map(p => (
                <tr key={p.id} className="border-b border-[#f5f5f5] hover:bg-[#fafafa]">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <img src={p.image} alt="" className="w-10 h-10 rounded-md object-cover" />
                      <div className="min-w-0">
                        <div className="text-xs font-medium line-clamp-1">{p.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-xs font-medium text-[#0A1F44]">${Number(p.price).toFixed(2)}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <button onClick={() => openEdit(p)} className="text-[#0A1F44]"><Edit className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(p.id)} className="text-[#E53935]"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminProducts;
