import AdminLayout from "@/components/admin/AdminLayout";

const orders = [
  { id: "ORD-101", customer: "أحمد محمد", email: "ahmed@email.com", total: 548, status: "جديد", date: "2026-03-07", items: 2, payment: "Stripe" },
  { id: "ORD-100", customer: "سارة علي", email: "sara@email.com", total: 1299, status: "قيد الشحن", date: "2026-03-06", items: 1, payment: "PayPal" },
  { id: "ORD-099", customer: "محمود حسن", email: "mahmoud@email.com", total: 228, status: "تم التوصيل", date: "2026-03-05", items: 3, payment: "Stripe" },
  { id: "ORD-098", customer: "فاطمة يوسف", email: "fatma@email.com", total: 899, status: "تم التوصيل", date: "2026-03-04", items: 1, payment: "PayPal" },
  { id: "ORD-097", customer: "عمر خالد", email: "omar@email.com", total: 349, status: "ملغي", date: "2026-03-03", items: 2, payment: "Stripe" },
  { id: "ORD-096", customer: "نورا أشرف", email: "nora@email.com", total: 1599, status: "جديد", date: "2026-03-02", items: 4, payment: "Stripe" },
];

const AdminOrders = () => (
  <AdminLayout>
    <h1 className="text-2xl font-bold mb-6">إدارة الطلبات ({orders.length})</h1>

    <div className="bg-card rounded-lg border border-border overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="text-right p-3">رقم الطلب</th>
            <th className="text-right p-3">العميل</th>
            <th className="text-right p-3">البريد</th>
            <th className="text-right p-3">المبلغ</th>
            <th className="text-right p-3">المنتجات</th>
            <th className="text-right p-3">الدفع</th>
            <th className="text-right p-3">الحالة</th>
            <th className="text-right p-3">التاريخ</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.id} className="border-b border-border hover:bg-muted/50">
              <td className="p-3 font-semibold">{order.id}</td>
              <td className="p-3">{order.customer}</td>
              <td className="p-3 text-muted-foreground">{order.email}</td>
              <td className="p-3 font-semibold">{order.total.toLocaleString()} ج.م</td>
              <td className="p-3">{order.items}</td>
              <td className="p-3"><span className="text-xs bg-muted px-2 py-0.5 rounded">{order.payment}</span></td>
              <td className="p-3">
                <span className={`text-xs px-2 py-1 rounded-full ${
                  order.status === "جديد" ? "bg-blue-100 text-blue-700" :
                  order.status === "قيد الشحن" ? "bg-store-accent/20 text-store-accent" :
                  order.status === "تم التوصيل" ? "bg-green-100 text-green-700" :
                  "bg-red-100 text-red-700"
                }`}>{order.status}</span>
              </td>
              <td className="p-3 text-muted-foreground">{order.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </AdminLayout>
);

export default AdminOrders;
