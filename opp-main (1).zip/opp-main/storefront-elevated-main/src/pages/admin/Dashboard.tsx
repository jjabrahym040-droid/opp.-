import AdminLayout from "@/components/admin/AdminLayout";
import { Package, ShoppingBag, Users, CreditCard, TrendingUp, DollarSign } from "lucide-react";

const stats = [
  { label: "إجمالي المنتجات", value: "12", icon: Package, color: "text-primary" },
  { label: "الطلبات الجديدة", value: "28", icon: ShoppingBag, color: "store-success" },
  { label: "العملاء المسجلين", value: "1,245", icon: Users, color: "text-primary" },
  { label: "إجمالي الإيرادات", value: "45,890 ج.م", icon: DollarSign, color: "text-foreground" },
];

const recentOrders = [
  { id: "ORD-101", customer: "أحمد محمد", total: 548, status: "جديد", date: "2026-03-07" },
  { id: "ORD-100", customer: "سارة علي", total: 1299, status: "قيد الشحن", date: "2026-03-06" },
  { id: "ORD-099", customer: "محمود حسن", total: 228, status: "تم التوصيل", date: "2026-03-05" },
  { id: "ORD-098", customer: "فاطمة يوسف", total: 899, status: "تم التوصيل", date: "2026-03-04" },
  { id: "ORD-097", customer: "عمر خالد", total: 349, status: "ملغي", date: "2026-03-03" },
];

const AdminDashboard = () => (
  <AdminLayout>
    <h1 className="text-xl font-bold mb-5">لوحة التحكم</h1>

    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
      {stats.map(s => (
        <div key={s.label} className="bg-card rounded border border-border p-4">
          <div className="flex items-center justify-between mb-2">
            <s.icon className={`w-7 h-7 ${s.color}`} />
            <TrendingUp className="w-4 h-4 store-success" />
          </div>
          <div className="text-xl font-bold">{s.value}</div>
          <div className="text-xs text-muted-foreground">{s.label}</div>
        </div>
      ))}
    </div>

    <div className="bg-card rounded border border-border">
      <div className="p-3 border-b border-border">
        <h2 className="font-bold text-sm">أحدث الطلبات</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-muted-foreground">
              <th className="text-right p-3 text-xs">رقم الطلب</th>
              <th className="text-right p-3 text-xs">العميل</th>
              <th className="text-right p-3 text-xs">المبلغ</th>
              <th className="text-right p-3 text-xs">الحالة</th>
              <th className="text-right p-3 text-xs">التاريخ</th>
            </tr>
          </thead>
          <tbody>
            {recentOrders.map(order => (
              <tr key={order.id} className="border-b border-border hover:bg-muted/50">
                <td className="p-3 font-semibold text-xs">{order.id}</td>
                <td className="p-3 text-xs">{order.customer}</td>
                <td className="p-3 font-semibold text-xs">{order.total.toLocaleString()} ج.م</td>
                <td className="p-3">
                  <span className={`text-[10px] px-2 py-0.5 rounded ${
                    order.status === "جديد" ? "bg-primary/10 text-primary" :
                    order.status === "قيد الشحن" ? "bg-primary/10 text-primary" :
                    order.status === "تم التوصيل" ? "bg-green-50 text-green-700" :
                    "bg-red-50 text-red-700"
                  }`}>
                    {order.status}
                  </span>
                </td>
                <td className="p-3 text-muted-foreground text-xs">{order.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </AdminLayout>
);

export default AdminDashboard;
