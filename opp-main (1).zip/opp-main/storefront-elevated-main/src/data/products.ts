// Type definitions only. Live data comes from Supabase via useProducts/useCategories hooks.

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  images: string[];
  rating: number;
  reviewCount: number;
  soldCount: number;
  inStock: boolean;
  stockCount: number;
  brand: string;
  store: string;
  features: string[];
  isSuperDeal?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  image?: string;
}

// Empty fallbacks — the live data is fetched from Supabase.
export const products: Product[] = [];
export const categories: Category[] = [];
